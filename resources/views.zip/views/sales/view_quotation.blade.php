<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    {{-- import style.css --}}
    {{-- <link rel="stylesheet" href="{{ asset('') }}assets/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css"> --}}
    <link rel="stylesheet" href="{{ asset('assets/dist/css/adminlte.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/page.css') }}">
    {{-- <link rel="stylesheet" href="{{ asset('css/page.css') }}"> --}}
    <script src="{{ asset('') }}assets/plugins/jquery/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.min.js"></script>
    <script type="text/javascript">
        // on page loaded print console
        $(document).ready(function() {

            $('#printButton').on('click', function(e) {
                e.preventDefault();
                // window.print with file name



                window.print();

            });



        });
    </script>
    <title>{{ $quotation['quotation_number'] }}</title>
    <link rel="icon" href="{{ asset('') }}assets/dist/img/logo_etn.png">
    <meta property="og:title" content="{{ $quotation['quotation_number'] }}" />
    <meta property="og:description" content="{{ $quotation['title'] }}" />
    <meta property="og:image" content="https://invoice.etn.co.id/assets/dist/img/logo_etn_sm.png" />
</head>

<body>
    <div class="a4ben sheet" id="section-to-print">
        {{-- <page size="A4"> --}}

        <div class="col-12">
            <div class="row" id="pdf-page">
                <div class="col-8 mt-2">
                    <h4>
                        <div class="row justify-content-center">
                            <img src="{{ asset('') }}assets/dist/img/logo_etn.png" alt="logo"
                                class="brand-image " style="opacity: .8" height="80" width="80">
                            <div class="col justify-content-center flex-column normal">
                                <b>EZA TEKNOLOGI NUSANTARA</b> <br>
                                <i>Mechanical, Electrical & IT Solutions</i> <br>
                                Jl. Cut Nyak Dhien, Cijoho, (Sebelah Utara Kamps UNIKU 1)<br>
                                Kuningan - Jawa Barat 45513 <br>
                                0232 -890 2107 / sales@etn.co.id


                            </div>

                        </div>

                    </h4>
                </div>
                <div class="col-4 mt-1  text-right ">
                    <h4>
                        <div class="col m-0 normal">
                            <strong>
                                #{{ $quotation['quotation_number'] }}
                            </strong><br>
                            <strong>
                                Valid Until {{ $quotation['due_date'] }}
                            </strong>
                            <br><br>

                            <button type="button" class="btn btn-success btn-sm" id="printButton">
                                Print This Page
                            </button>




                        </div>
                    </h4>


                </div>




            </div>
            <hr class="m-1">

            <div class="row">
                <div class="col-4">
                    <h6>

                        <div class="col small">
                            <b>Quoted to :</b><br>
                            {{ $company['name'] }} <br>
                            Attn: {{ $customer['name'] }}<br>
                            {{ $customer['address'] }}<br>
                            {{ $customer['city'] }}, {{ $customer['state'] }} {{ $customer['zip_code'] }}<br>
                            Phone: {{ $customer['phone'] }}<br>
                            Email: {{ $customer['email'] }}

                        </div>
                    </h6>

                </div>


                <div class="col-4">
                    <h6>
                        <div class="col small">
                            <b>Details :</b><br>
                            Quotation # : {{ $quotation['quotation_number'] }}<br>
                            Quotation Date : {{ $quotation['date'] }}<br>
                            Expiry Date : {{ $quotation['due_date'] }}<br>


                        </div>


                    </h6>
                </div>
                <div class="col-4">
                    <div class="col normal  text-right">


                        Grand Total : Rp
                        {{ number_format($quotation['total'], 2, ',', '.') }}<br>


                    </div>

                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <h6>

                        <div class="col small">
                            <strong>
                                Subject : {{ $quotation['title'] }}
                            </strong>
                        </div>
                    </h6>

                </div>
            </div>
            <div class="row">
                <div class="col-12 pt-2">
                    <h6>

                        <div class="col small">

                            {!! $quotation['header'] !!}

                        </div>
                    </h6>

                </div>
            </div>

            <div class="row" id="table_container ">
                <div class="col-12 ">
                    @foreach ($quotation_details as $card)
                        <table class="table-bordered small mb-3" id="{{ $card['subid'] }}">
                            <thead style="background-color: rgb(218, 230, 230)">
                                <tr class="text-center">
                                    <th width="35% ">Name</th>
                                    <th width="10% ">Type</th>
                                    <th width="10% ">Brand</th>
                                    <th width="10% ">Price</th>
                                    <th width="5% ">Qty</th>
                                    <th width="5% ">Unit</th>
                                    <th width="5% ">Disc(%)</th>
                                    <th width="10% ">Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <td colspan="8" class=" pl-2 pr-2">
                                    <strong>{{ $card['sub_title'] }}</strong>
                                </td>
                                @foreach ($card['details'] as $item)
                                    <tr id="item">
                                        <td class="pl-2 pr-2">
                                            {{ $item['name'] }}
                                            @if ($item['note'] != null)
                                                <br>
                                                {!! $item['note'] !!}
                                            @endif
                                        </td>
                                        <td class="text-center " style="vertical-align:top">{{ $item['type'] }}
                                        </td>
                                        <td class="text-center " style="vertical-align:top">{{ $item['brand'] }}
                                        </td>
                                        <td class="text-right pr-2" style="vertical-align:top">
                                            {{ number_format($item['price'], 2, ',', '.') }}</td>
                                        <td class="text-center " style="vertical-align:top" id="unit">
                                            {{ $item['qty'] }}
                                        </td>
                                        <td class="text-center " style="vertical-align:top">{{ $item['unit'] }}
                                        </td>
                                        <td class="text-center pr-2" style="vertical-align:top" id="discount">
                                            {{ number_format($item['item_discount'], 2, ',', '.') }}
                                        </td>
                                        <td class="text-right pr-2" style="vertical-align:top" id="ammount"
                                            value="{{ $item['ammount'] }}">
                                            {{ number_format($item['ammount'], 2, ',', '.') }}</td>
                                    </tr>
                                @endforeach


                            <tfoot>
                                @if ($card['discount'] != 0)
                                    <tr>
                                        <td colspan="7 " class="text-right pr-2 "><strong>Total Before Disc
                                                (IDR)</strong>
                                        </td>
                                        <td class="text-right pr-2 " id="discount_{{ $card['subid'] }}">
                                            <strong>{{ number_format($card['sub_total'], 2, ',', '.') }}</strong>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="7 " class="text-right pr-2 "><strong>Discount (IDR)</strong>
                                        </td>
                                        <td class="text-right pr-2 " id="discount_{{ $card['subid'] }}">
                                            <strong>{{ number_format($card['discount'], 2, ',', '.') }}</strong>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="7 " class="text-right pr-2 "><strong>Sub Total (IDR)</strong>
                                        </td>
                                        <td class="text-right pr-2 " id="total_{{ $card['subid'] }}">
                                            <strong>{{ number_format($card['total'], 2, ',', '.') }}</strong>
                                        </td>
                                    </tr>
                                @else
                                    <tr>
                                        <td colspan="7 " class="text-right pr-2 "><strong>Sub Total (IDR)</strong>
                                        </td>
                                        <td class="text-right pr-2 " id="total_{{ $card['subid'] }}">
                                            <strong>{{ number_format($card['total'], 2, ',', '.') }}</strong>
                                        </td>
                                    </tr>
                                @endif

                            </tfoot>

                            </tbody>
                        </table>
                    @endforeach


                </div>

            </div>
            <div class="row">

                <div class="col-7 pl-4 small">
                    {{-- signature box client and seller --}}



                </div>


                <div class=" col-5 ">

                    <div class="row text-right">
                        <div class="col-7 pr-4">
                            <p class="m-0">Total Before Disc (IDR)</p>
                            @if ($quotation['sub_discount_value'] != 0)
                                <p class="m-0">Sub Discount (IDR)</p>
                            @endif

                            @if ($quotation['discount_value'] != 0)
                                @if ($quotation['discount_type'] == 'percent')
                                    <p class="m-0">Discount
                                        ({{ number_format($quotation['discount'], 2, ',', '.') }}%) (IDR)</p>
                                @endif
                                @if ($quotation['discount_type'] == 'total')
                                    <p class="m-0">Discount (IDR)</p>
                                @endif
                            @endif


                            <p class="m-0">Grand Total (IDR)</p>
                        </div>
                        <div class="col-5 pr-4">
                            <p class="m-0">{{ number_format($quotation['subtotal'], 2, ',', '.') }}</p>
                            @if ($quotation['sub_discount_value'] != 0)
                                <p class="m-0">
                                    {{ number_format($quotation['sub_discount_value'], 2, ',', '.') }}
                                </p>
                            @endif


                            @if ($quotation['discount_value'] != 0)
                                <p class="m-0">{{ number_format($quotation['discount_value'], 2, ',', '.') }}
                                </p>
                            @endif
                            <p class="m-0">{{ number_format($quotation['total'], 2, ',', '.') }}</p>
                        </div>
                    </div>

                </div>

            </div>
            <div class="row">
                <div class="col-12 pt-2">
                    <h6>

                        <div class="col small">

                            {!! $quotation['footer'] !!}

                        </div>
                    </h6>

                </div>
            </div>


            <div class="row">

                <div class="col-6 pl-4 small">
                    {{-- signature box client and seller --}}
                    <div class="row text-left">
                        {{-- strong italic --}}
                        <strong><i>"This is computer genereted quotation, no signature required."</i></strong>
                    </div>


                </div>


                <div class=" col-5 ">

                </div>

            </div>




            @if ($quotation['notes'] != '')
                <hr class="mt-1 mb-1">
                <div class="col-7 small">
                    <b>Notes:</b><br>
                    {!! $quotation['notes'] !!}
                </div>
            @endif

        </div>
    </div>
</body>



</html>

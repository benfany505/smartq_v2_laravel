<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>AdminLTE 3 | Invoice Print</title>

    <!-- Google Font: Source Sans Pro -->
    {{-- <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback"> --}}
    <!-- Font Awesome -->
    <link rel="stylesheet" href="{{ asset('assets/plugins/fontawesome-free/css/all.min.css') }}">
    <!-- Theme style -->
    <link rel="stylesheet" href="{{ asset('assets/dist/css/adminlte.min.css') }}">


</head>

<body>
    <div class="wrapper">
        <!-- Main content -->
        <section class="invoice">
            <div class="invoice p-3 mb-3">





                <div class="row">
                    <div class="col-6 mt-1">
                        <h4>

                            <div class="row justify-content-center">
                                <img src="{{ asset('assets/dist/img/logo_etn.png') }}" alt="logo"
                                    class="brand-image " style="opacity: .8" height="100" width="100">
                                <div class="col justify-content-center flex-column">
                                    Eza Teknologi Nusantara <br>
                                    <h6>
                                        <i>"Mechanical, Electrical & IT Solutions"</i>
                                        <br>
                                        Jl. Cut Nyak Dhien (Sebelah Utara Kampus Uniku 1) <br>
                                        Cijoho, Kuningan - Jawa Barat 45571 <br>
                                        0232 -890 2107 / sales@etn.co.id
                                    </h6>

                                </div>

                            </div>

                        </h4>
                    </div>
                    <div class="col-6 mt-1 text-right">
                        <h4>
                            <strong>
                                #INV-202206-UNIKU-0001
                            </strong>
                        </h4>

                        <h3>
                            <span class="badge badge-success">Paid</span>
                        </h3>



                    </div>




                </div>


                <div class="row invoice-info">
                    <div class="col-sm-8 invoice-col">
                        <h5>Invoiced to :
                        </h5>
                        <address>

                            <h6>
                                Universitas Kuningan <br>
                                Attn: Bag. Keuangan / Perlengkapan<br>
                                Jalan Cut Nyak Dien<br>
                                Cijoho, Kuningan 45513<br>
                                Phone: (0232) 8902107<br>
                                Email: sales@etn.co.id
                            </h6>
                        </address>
                    </div>


                    <div class="col-sm-4 invoice-col">
                        <h5>Details :</h5>
                        <h6>
                            Quotation # : On Call<br>
                            Invoice # : INV-202206-UNIKU-0001<br>
                            Job Date : 1-Juni-2022<br>
                            Invoice Date :</b> 7-Juni-2022<br>
                            Due Date : 14-Juni-2022<br>
                        </h6>
                    </div>




                </div>


                <div class="row invoice-info mb-2">
                    <div class="col-sm-8 invoice-col">

                        <h6>
                            <u>
                                <strong>
                                    Pengadaan Barang dan Instalasi Jaringan Komputer
                                </strong>
                            </u>
                        </h6>

                    </div>
                    <div class="col-sm-4 invoice-col ">
                        <h5>

                            Invoice Total (IDR) : 2,250,000.00



                        </h5>
                    </div>
                </div>




                <div class="row">
                    <div class="col-12 table-responsive">
                        <table class="table table-bordered table-sm">
                            <thead style="background-color: rgb(218, 230, 230)">
                                <tr class="text-center">
                                    <th width="35% ">Name</th>
                                    <th width="10% ">Type</th>
                                    <th width="10% ">Brand</th>
                                    <th width="10% ">Price (IDR)</th>
                                    <th width="5% ">Qty</th>
                                    <th width="5% ">Unit</th>
                                    <th width="5% ">Disc(%)</th>
                                    <th width="10% ">Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <td colspan="8">
                                    <strong>Sub Title #1</strong>
                                </td>
                                <tr>
                                    <td class="p-2">
                                        Ubiquiti Unifi AP-AC Lite <br>
                                        &nbsp;&nbsp;&nbsp;&nbsp;Garansi 1 bulan
                                    </td>
                                    <td class="text-center p-2" style="vertical-align:top">AP-AC LIte</td>
                                    <td class="text-center p-2" style="vertical-align:top">UBIQUITI</td>
                                    <td class="text-right p-2" style="vertical-align:top">2,450,000.00</td>
                                    <td class="text-center p-2" style="vertical-align:top">1</td>
                                    <td class="text-center p-2" style="vertical-align:top">pcs</td>
                                    <td class="text-center p-2" style="vertical-align:top">5</td>
                                    <td class="text-right p-2" style="vertical-align:top">2,327,500.00</td>
                                </tr>
                                <tr>
                                    <td class="p-2">HTB Netlink 100 Mbps
                                    </td>
                                    <td class="text-center p-2" style="vertical-align:top">100 Mbps</td>
                                    <td class="text-center p-2" style="vertical-align:top">NETLINK</td>
                                    <td class="text-right p-2" style="vertical-align:top">175,000.00</td>
                                    <td class="text-center p-2" style="vertical-align:top">1</td>
                                    <td class="text-center p-2" style="vertical-align:top">paket</td>
                                    <td class="text-center p-2" style="vertical-align:top">0</td>
                                    <td class="text-right p-2" style="vertical-align:top">175,000.00</td>
                                </tr>
                                <tr>
                                    <td class="p-2">HTB Netlink 100 Mbps
                                    </td>
                                    <td class="text-center p-2" style="vertical-align:top">100 Mbps</td>
                                    <td class="text-center p-2" style="vertical-align:top">NETLINK</td>
                                    <td class="text-right p-2" style="vertical-align:top">175,000.00</td>
                                    <td class="text-center p-2" style="vertical-align:top">1</td>
                                    <td class="text-center p-2" style="vertical-align:top">paket</td>
                                    <td class="text-center p-2" style="vertical-align:top">0</td>
                                    <td class="text-right p-2" style="vertical-align:top">175,000.00</td>
                                </tr>
                                <tr>
                                    <td class="p-2">HTB Netlink 100 Mbps
                                    </td>
                                    <td class="text-center p-2" style="vertical-align:top">100 Mbps</td>
                                    <td class="text-center p-2" style="vertical-align:top">NETLINK</td>
                                    <td class="text-right p-2" style="vertical-align:top">175,000.00</td>
                                    <td class="text-center p-2" style="vertical-align:top">1</td>
                                    <td class="text-center p-2" style="vertical-align:top">paket</td>
                                    <td class="text-center p-2" style="vertical-align:top">0</td>
                                    <td class="text-right p-2" style="vertical-align:top">175,000.00</td>
                                </tr>
                                <tr>
                                    <td class="p-2">HTB Netlink 100 Mbps
                                    </td>
                                    <td class="text-center p-2" style="vertical-align:top">100 Mbps</td>
                                    <td class="text-center p-2" style="vertical-align:top">NETLINK</td>
                                    <td class="text-right p-2" style="vertical-align:top">175,000.00</td>
                                    <td class="text-center p-2" style="vertical-align:top">1</td>
                                    <td class="text-center p-2" style="vertical-align:top">paket</td>
                                    <td class="text-center p-2" style="vertical-align:top">0</td>
                                    <td class="text-right p-2" style="vertical-align:top">175,000.00</td>
                                </tr>
                                <tr>
                                    <td colspan="7 " class="text-right  "><strong>Sub Total</strong> </td>
                                    <td class="text-right p-2 " style="background-color: rgb(177, 239, 255)">
                                        <strong>0</strong>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="7 " class="text-right  "><strong>Discount (IDR)</strong> </td>
                                    <td class="text-right p-2 " style="background-color: rgb(177, 239, 255)">
                                        <strong>0</strong>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="7 " class="text-right  "><strong>Total (IDR)</strong> </td>
                                    <td class="text-right p-2 " style="background-color: rgb(177, 239, 255)">
                                        <strong>0</strong>
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                        <table class="table table-bordered table-sm">
                            <thead style="background-color: rgb(218, 230, 230)">
                                <tr class="text-center">
                                    <th width="35% ">Name</th>
                                    <th width="10% ">Type</th>
                                    <th width="10% ">Brand</th>
                                    <th width="10% ">Price (IDR)</th>
                                    <th width="5% ">Qty</th>
                                    <th width="5% ">Unit</th>
                                    <th width="5% ">Disc(%)</th>
                                    <th width="10% ">Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <td colspan="8">
                                    <strong>Sub Title #1</strong>
                                </td>
                                <tr>
                                    <td class="p-2">
                                        Ubiquiti Unifi AP-AC Lite <br>
                                        &nbsp;&nbsp;&nbsp;&nbsp;Garansi 1 bulan
                                    </td>
                                    <td class="text-center p-2" style="vertical-align:top">AP-AC LIte</td>
                                    <td class="text-center p-2" style="vertical-align:top">UBIQUITI</td>
                                    <td class="text-right p-2" style="vertical-align:top">2,450,000.00</td>
                                    <td class="text-center p-2" style="vertical-align:top">1</td>
                                    <td class="text-center p-2" style="vertical-align:top">pcs</td>
                                    <td class="text-center p-2" style="vertical-align:top">5</td>
                                    <td class="text-right p-2" style="vertical-align:top">2,327,500.00</td>
                                </tr>
                                <tr>
                                    <td class="p-2">HTB Netlink 100 Mbps
                                    </td>
                                    <td class="text-center p-2" style="vertical-align:top">100 Mbps</td>
                                    <td class="text-center p-2" style="vertical-align:top">NETLINK</td>
                                    <td class="text-right p-2" style="vertical-align:top">175,000.00</td>
                                    <td class="text-center p-2" style="vertical-align:top">1</td>
                                    <td class="text-center p-2" style="vertical-align:top">paket</td>
                                    <td class="text-center p-2" style="vertical-align:top">0</td>
                                    <td class="text-right p-2" style="vertical-align:top">175,000.00</td>
                                </tr>
                                <tr>
                                    <td class="p-2">HTB Netlink 100 Mbps
                                    </td>
                                    <td class="text-center p-2" style="vertical-align:top">100 Mbps</td>
                                    <td class="text-center p-2" style="vertical-align:top">NETLINK</td>
                                    <td class="text-right p-2" style="vertical-align:top">175,000.00</td>
                                    <td class="text-center p-2" style="vertical-align:top">1</td>
                                    <td class="text-center p-2" style="vertical-align:top">paket</td>
                                    <td class="text-center p-2" style="vertical-align:top">0</td>
                                    <td class="text-right p-2" style="vertical-align:top">175,000.00</td>
                                </tr>
                                <tr>
                                    <td class="p-2">HTB Netlink 100 Mbps
                                    </td>
                                    <td class="text-center p-2" style="vertical-align:top">100 Mbps</td>
                                    <td class="text-center p-2" style="vertical-align:top">NETLINK</td>
                                    <td class="text-right p-2" style="vertical-align:top">175,000.00</td>
                                    <td class="text-center p-2" style="vertical-align:top">1</td>
                                    <td class="text-center p-2" style="vertical-align:top">paket</td>
                                    <td class="text-center p-2" style="vertical-align:top">0</td>
                                    <td class="text-right p-2" style="vertical-align:top">175,000.00</td>
                                </tr>
                                <tr>
                                    <td class="p-2">HTB Netlink 100 Mbps
                                    </td>
                                    <td class="text-center p-2" style="vertical-align:top">100 Mbps</td>
                                    <td class="text-center p-2" style="vertical-align:top">NETLINK</td>
                                    <td class="text-right p-2" style="vertical-align:top">175,000.00</td>
                                    <td class="text-center p-2" style="vertical-align:top">1</td>
                                    <td class="text-center p-2" style="vertical-align:top">paket</td>
                                    <td class="text-center p-2" style="vertical-align:top">0</td>
                                    <td class="text-right p-2" style="vertical-align:top">175,000.00</td>
                                </tr>
                                <tr>
                                    <td colspan="7 " class="text-right  "><strong>Sub Total (IDR)</strong> </td>
                                    <td class="text-right p-2 " style="background-color: rgb(177, 239, 255)">
                                        <strong>0</strong>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="7 " class="text-right  "><strong>Discount (IDR)</strong> </td>
                                    <td class="text-right p-2 " style="background-color: rgb(177, 239, 255)">
                                        <strong>0</strong>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="7 " class="text-right  "><strong>Total (IDR)</strong> </td>
                                    <td class="text-right p-2 " style="background-color: rgb(177, 239, 255)">
                                        <strong>0</strong>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                </div>

                <div class="row">

                    <div class="col-8">




                        <p class="lead">Notes:</p>
                        <p class="text-muted well well-sm shadow-none">
                        <ul>
                            <li>Barang yang sudah dibeli tidak dapat dikembalikan</li>
                            <li>Kelebihan material (jika ada) akan dikembalikan kepihak pembeli</li>
                            <li>Garansi barang mengikuti garansi resmi distributor</li>
                            <li>Garansi instalasi selama 1 bulan</li>
                        </ul>


                    </div>

                    <div class=" col-4">

                        <div class="table-responsive">
                            <table class="table table-sm">
                                <tr>
                                    <th>
                                        <h6>Sub Total (IDR)</h6>
                                    </th>
                                    <td class="text-right">
                                        <h6>2,750,000.00</h6>
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        <h6>Discount Total (IDR)</h6>
                                    </th>
                                    <td class="text-right">
                                        <h6>500,000.00</h6>
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        <h6> Shipping (IDR)</h6>
                                    </th>
                                    <td class="text-right">
                                        <h6> 0.00</h6>
                                    </td>
                                </tr>
                                <tr>
                                    <th>
                                        <h6>Grand Total (IDR)</h6>
                                    </th>
                                    <td class="text-right">
                                        <h4> <b> 2.250.000.00</b></h4>
                                    </td>

                                </tr>

                            </table>

                        </div>
                    </div>

                </div>


                <div class="row no-print">
                    <div class="col-12">
                        <a href="invoice-print.html" rel="noopener" target="_blank" class="btn btn-default"><i
                                class="fas fa-print"></i> Print</a>
                        <button type="button" class="btn btn-success float-right"><i class="far fa-credit-card"></i>
                            Submit
                            Payment
                        </button>
                        <button type="button" class="btn btn-primary float-right" style="margin-right: 5px;">
                            <i class="fas fa-download"></i> Generate PDF
                        </button>
                    </div>
                </div>
            </div>


        </section>
        <!-- /.content -->
    </div>
    <!-- ./wrapper -->
    <!-- Page specific script -->
    <script>
        window.addEventListener("load", window.print());
    </script>
</body>

</html>

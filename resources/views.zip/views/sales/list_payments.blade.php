@extends('layouts.master')
@section('title', 'ETN | Invoice')
@push('custom-css')
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet"
        href="{{ asset('') }}assets/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="{{ asset('') }}assets/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- JQVMap -->
    <link rel="stylesheet" href="{{ asset('') }}assets/plugins/jqvmap/jqvmap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="{{ asset('') }}assets/dist/css/adminlte.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="{{ asset('') }}assets/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="{{ asset('') }}assets/plugins/daterangepicker/daterangepicker.css">
    <!-- summernote -->
    <link rel="stylesheet" href="{{ asset('') }}assets/plugins/summernote/summernote-bs4.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href=" {{ asset('') }}assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet"
        href=" {{ asset('') }}assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href=" {{ asset('') }}assets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
@endpush
@section('content')

    {{-- @foreach ($payments as $payment)
        <p>{{  $payment['invoice_number'] }}</p>
    @endforeach --}}

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <div class="panel-body">
                        <a href="" class="btn btn-info btn-sm"><i class="fa fa-download"></i> Download List</a>

                    </div>
                </div>



                <div class="card-body table-responsive">
                    <table id="example1" class="table text-nowrap table-bordered table-striped table-sm">
                        <thead class="table-primary">
                            <tr class="text-center">
                                <th width="5%">ID</th>
                                <th width="22%">Customer</th>
                                <th width="35%">Desctiption</th>
                                <th width="6%">Date</th>
                                <th width="7%">TRX ID</th>
                                <th width="10%">Amount</th>
                                <th width="7%">Methode</th>
                                <th width="8%">Manage</th>

                            </tr>
                        </thead>
                        <tbody>

                            {{-- echo  $payments --}}


                            @foreach ($payments as $payment)
                                <tr class="text-center">
                                    <td>{{ $payment['invoice_number'] }}</td>
                                    <td class="text-left">{{ $payment['payer_id'] }}</td>
                                    <td class="text-left">{{ $payment['description'] }}</td>
                                    <td>{{ $payment['date'] }}</td>
                                    <td>{{ $payment['transaction_id'] }}</td>
                                    <td class="text-right">{{ number_format($payment['ammount'], 0, ',', '.') }}
                                    </td>
                                    <td>{{ $payment['method'] }}</td>
                                    <td class="text-center">
                                        <a href="/preview_invoice/{{ $payment['invoice_number'] }}">
                                            <button account="button" class="btn btn-success btn-xs" data-toggle="modal"
                                                title="View">
                                                <i class="fa fa-eye"></i>
                                            </button>
                                        </a>
                                        <button account="button" class="btn btn-info btn-xs" data-toggle="modal"
                                            data-placement="top" title="Edit"
                                            data-target="#modal-edit-{{ $payment['id'] }}">
                                            <i class="fa fa-edit"></i>
                                        </button>

                                        <button account="button" class="btn btn-danger btn-xs" data-toggle="modal"
                                            data-placement="top" title="Delete"
                                            data-target="#modal-delete-{{ $payment['id'] }}"><i class="fa fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            @endforeach

                        </tbody>
                        {{-- <tfoot class="table-primary text-center">
                    <tr>
                        <th width="10%">ID Prod</th>
                        <th width="35%">Name</th>
                        <th width="15%">Type</th>
                        <th width="15%">Brand</th>
                        <th width="15%">Price (IDR)</th>
                        <th width="5%">Unit</th>
                        <th width="5%">Manage</th>
                    </tr>
                </tfoot> --}}
                    </table>
                </div>
            </div>
        </div>
    </div>

    @foreach ($payments as $payment)
        <div class="modal fade" id="modal-delete-{{ $payment['id'] }}">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Delete Confirmation</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p>Are you sure want to delete payment for{{ $payment['invoice_number'] }}, Amount
                            {{ number_format($payment['ammount'], 0, ',', '.') }}?</p>

                    </div>
                    <div class="modal-footer justify-content-between">
                        {{-- button on click yes go to url with request data method delete --}}
                        <form action="/delete_payment/{{ $payment['id'] }}" method="POST">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Yes</button>
                        </form>
                        <button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        <div class="modal fade" id="modal-edit-{{ $payment['id'] }}">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Payment {{ $payment['invoice_number'] }}</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="/list_payments/{{ $payment['id'] }}" method="POST">
                            @csrf
                            @method('PUT')
                            <input type="text" name="id_invoice" id="id_invoice"
                                value="{{ $payment['invoice_number'] }}" hidden>

                            <div class="row">
                                <div class="col-lg-12 pl-2 pr-2">
                                    <div class="form-group row">
                                        <label for="inputEmail3" class="col-sm-3 col-form-label  ">Customer</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="payer_id" name="payer_id"
                                                placeholder="Name" value="{{ $payment['payer_id'] }}" readonly>
                                        </div>
                                    </div>
                                    {{-- dropdown box --}}

                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label">Account</label>
                                        <div class="col-sm-9">
                                            <select type="text" class="form-control" id="account" name="account"
                                                placeholder="Account">
                                                <option value="{{ $payment['account'] }}" selected>
                                                    {{ $payment['account'] }}</option>
                                                @foreach ($accounts as $item)
                                                    <option value="{{ $item['name'] }}">
                                                        {{ $item['name'] }} | {{ $item['desc'] }}
                                                    </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label">Date</label>
                                        <div class="col-sm-9">
                                            <input type="date" class="form-control" id="date" name="date"
                                                value="{{ $payment['date'] }}" placeholder="Date">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label">Amount</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="ammount" name="ammount"
                                                placeholder="Amount" value="{{ $payment['ammount'] }}">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label">Trx ID</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="trx_id" name="trx_id"
                                                placeholder="Transaction ID" value="{{ $payment['transaction_id'] }}">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label">Method</label>
                                        <div class="col-sm-9">
                                            <select type="text" class="form-control" id="metod" name="method"
                                                placeholder="Method">
                                                <option value="{{ $payment['method'] }}" selected>
                                                    {{ $payment['method'] }}</option>
                                                <option value="Cash">Cash</option>
                                                <option value="Bank Transfer">Bank Transfer</option>
                                                <option value="Credit Card">Credit Card</option>
                                                <option value="Debit Card">Debit Card</option>
                                                <option value="E-Money">E-Money</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label">Category</label>
                                        <div class="col-sm-9">
                                            <select type="text" class="form-control" id="category" name="category"
                                                placeholder="Category">
                                                <option value="{{ $payment['category'] }}" selected>
                                                    {{ $payment['category'] }}</option>
                                                <option value="Regular Income">Regular Income</option>
                                                <option value="Custom Software">Custom Software</option>
                                                <option value="Custom Hardware">Custom Hardware</option>
                                                <option value="Custom System">Custom System</option>
                                                <option value="Goods and Services">Goods and Services</option>
                                                <option value="Uncategorized">Uncategorized</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label">Description</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="description"
                                                name="description" placeholder="Description"
                                                value="{{ $payment['description'] }}">
                                        </div>
                                    </div>



                                </div>
                            </div>
                            <div class="modal-footer justify-content-between">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                {{-- button on click yes go to url with request data method update --}}

                                <button type="submit" class="btn btn-primary">Save</button>


                            </div>
                        </form>
                    </div>

                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
    @endforeach


@endsection
@push('custom-js')
    <!-- jQuery UI 1.11.4 -->
    <script src="{{ asset('') }}assets/plugins/jquery-ui/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
        $.widget.bridge('uibutton', $.ui.button)
    </script>
    <!-- Bootstrap 4 -->
    <script src="{{ asset('') }}assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- ChartJS -->
    <script src="{{ asset('') }}assets/plugins/chart.js/Chart.min.js"></script>
    <!-- Sparkline -->
    <script src="{{ asset('') }}assets/plugins/sparklines/sparkline.js"></script>
    <!-- JQVMap -->
    <script src="{{ asset('') }}assets/plugins/jqvmap/jquery.vmap.min.js"></script>
    <script src="{{ asset('') }}assets/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
    <!-- jQuery Knob Chart -->
    <script src="{{ asset('') }}assets/plugins/jquery-knob/jquery.knob.min.js"></script>
    <!-- daterangepicker -->
    <script src="{{ asset('') }}assets/plugins/moment/moment.min.js"></script>
    <script src="{{ asset('') }}assets/plugins/daterangepicker/daterangepicker.js"></script>
    <!-- Tempusdominus Bootstrap 4 -->
    <script src="{{ asset('') }}assets/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
    <!-- Summernote -->
    <script src="{{ asset('') }}assets/plugins/summernote/summernote-bs4.min.js"></script>
    <!-- overlayScrollbars -->
    <script src="{{ asset('') }}assets/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
    <!-- DataTables  & Plugins -->
    <script src=" {{ asset('') }}assets/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/jszip/jszip.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/pdfmake/pdfmake.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/pdfmake/vfs_fonts.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-buttons/js/buttons.print.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
    {{-- script before initialize modal --}}


    <script>
        $(function() {
            $("#example1").DataTable({
                "responsive": true,
                "lengthChange": true,
                "autoWidth": false,
                "buttons": ["copy", "csv", "excel", "pdf", "print"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": true,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });
        });
    </script>
    {{-- modal script --}}
    <script>
        $(function() {
            $('#exampleModal').on('show.bs.modal', function(event) {
                var button = $(event.relatedTarget) // Button that triggered the modal
                var recipient = button.data('whatever') // Extract info from data-* attributes
                // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
                // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
                var modal = $(this)
                modal.find('.modal-title').text('New message to ' + recipient)
                modal.find('.modal-body input').val(recipient)
            })
        })
    </script>
    <script>
        $(document).ready(function() {
            $('#modal-delete').on('show.bs.modal', function(event) {
                var button = $(event.relatedTarget)
                var recipient = button.data('whatever')
                var modal = $(this)
                modal.find('.modal-body input').val(recipient)
            })
        })
    </script>

    {{-- script if button click --}}
    <script>
        $(document).ready(function() {
            console.log('ready');
            // #ammount number only
            var amount = $('[id^="modal-edit-"]').find('#ammount');
            // print ammount[0] value
            for (var i = 0; i < amount.length; i++) {
                amount[i].value = amount[i].value.replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g,
                    ".");
                console.log(amount[i].value);
            }

            amount.keypress(function(e) {
                if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                    return false;
                }
            });
            amount.keyup(function(e) {
                var val = $(this).val();
                $(this).val(val.replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g,
                    "."));
            });

            // on submit form retun thousand separator to number
            $('[id^="modal-edit-"]').submit(function(e) {
                console.log('submit');
                var val = $(this).find('#ammount').val();
                for (var i = 0; i < amount.length; i++) {
                    amount[i].value = parseFloat(amount[i].value.replace(
                        /[^0-9\-]+/g,
                        ""));
                }

            });

        })
    </script>

    <script>
        $(function() {
            var Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000
            });

            // // run script when page loaded
            // $(document).ready(function() {

            // });
            // on reload
            @if (session()->has('success'))
                Toast.fire({
                    icon: 'success',
                    title: '{{ session()->get('success') }}',
                    timer: 3000,
                })
            @endif

            @if (session()->has('error'))
                Toast.fire({
                    icon: 'error',
                    title: '{{ session()->get('error') }}',
                    timer: 3000,
                })
            @endif

            $('.swalDefaultSuccess').click(function() {
                Toast.fire({
                    icon: 'success',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.swalDefaultInfo').click(function() {
                Toast.fire({
                    icon: 'info',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.swalDefaultError').click(function() {
                Toast.fire({
                    icon: 'error',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.swalDefaultWarning').click(function() {
                Toast.fire({
                    icon: 'warning',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.swalDefaultQuestion').click(function() {
                Toast.fire({
                    icon: 'question',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });

            $('.toastrDefaultSuccess').click(function() {
                toastr.success('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
            });
            $('.toastrDefaultInfo').click(function() {
                toastr.info('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
            });
            $('.toastrDefaultError').click(function() {
                toastr.error('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
            });
            $('.toastrDefaultWarning').click(function() {
                toastr.warning('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
            });

            $('.toastsDefaultDefault').click(function() {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultTopLeft').click(function() {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    position: 'topLeft',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultBottomRight').click(function() {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    position: 'bottomRight',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultBottomLeft').click(function() {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    position: 'bottomLeft',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultAutohide').click(function() {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    autohide: true,
                    delay: 750,
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultNotFixed').click(function() {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    fixed: false,
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultFull').click(function() {
                $(document).Toasts('create', {
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    icon: 'fas fa-envelope fa-lg',
                })
            });
            $('.toastsDefaultFullImage').click(function() {
                $(document).Toasts('create', {
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    image: '{{ asset('') }}assets/dist/img/user3-128x128.jpg',
                    imageAlt: 'User Picture',
                })
            });
            $('.toastsDefaultSuccess').click(function() {
                $(document).Toasts('create', {
                    class: 'bg-success',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultInfo').click(function() {
                $(document).Toasts('create', {
                    class: 'bg-info',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultWarning').click(function() {
                $(document).Toasts('create', {
                    class: 'bg-warning',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultDanger').click(function() {
                $(document).Toasts('create', {
                    class: 'bg-danger',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultMaroon').click(function() {
                $(document).Toasts('create', {
                    class: 'bg-maroon',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
        });
    </script>
@endpush

<div class="card card-info " id="card-888">
    <div class="card-header ">
        <h3 class="card-title ">Invoice Details #888 </h3>
    </div>
    <div class="card-body " id="sub_items "> {{-- button add sub group --}} <div class="row ">
            <div class="col-sm-12 table-responsive ">
                <div class="row ">
                    <div class="col-sm-5 mb-2 "> <input type="text " class="form-control form-control-sm "
                            name="sub_title " id="sub_title " placeholder="Sub Title "> </div>
                    <div class="col-sm-4 mb-2  "> <button type="button " class="btn btn-sm btn-primary "
                            id="add_blank_line-888"> <i class="      fas fa-plus "></i> Add Line
                        </button>
                        <button type="button " class="btn btn-sm btn-success " id="find_product-888"> <i
                                class="fas fa-search "></i> Find Products </button> <button type="button "
                            class="btn btn-sm btn-danger " id="delete_card-888"> <i class="fas fa-trash "></i>
                            Remove Sub </button> {{-- delete --}}
                    </div>
                    {{-- sub total text right --}} {{-- small button add row --}}
                </div>
                <div class="row ">
                    <div class="col-sm-12 ">
                        <table class="table text-nowrap table-bordered table-striped table-sm " id="table-" + 888>
                            <thead class="table-primary ">
                                <tr class="text-center ">
                                    <th width="35% ">Name</th>
                                    <th width="10% ">Type</th>
                                    <th width="10% ">Brand</th>
                                    <th width="10% ">Price (IDR)</th>
                                    <th width="5% ">Qty</th>
                                    <th width="5% ">Unit</th>
                                    <th width="5% ">Disc(%)</th>
                                    <th width="10% ">Amount (IDR)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <div class="input-group ">z
                                            <div class="col">
                                                <div class="input-group">
                                                    <button type="button " class="btn btn-danger btn-xs "
                                                        id="delete_row "><i class="fa fa-trash text-xs "></i>
                                                    </button>
                                                    <input type="text " class="form-control form-control-sm  "
                                                        name="name " id="name" placeholder="Name ">
                                                    <button type="button" class="btn btn-info btn-xs "
                                                        id="edit_note"><i id="icon_note"
                                                            class="fas fa-edit text-xs "></i>
                                                    </button>

                                                </div>

                                                {{-- summernote --}}
                                                <div class="row" id="note">
                                                    <div class="col-sm-12 ">
                                                        <textarea class="form-control" name="note " id="summernote" rows="3 " placeholder="Note" style="display: none;"></textarea>
                                                    </div>
                                                </div>



                                            </div>

                                        </div>
                                    </td>
                                    <td> <input type="text " class="form-control form-control-sm " name="name "
                                            id="type " placeholder="Type "> </td>
                                    <td> <Select class=" form-control form-control-sm " id="brand-888">
                                            <option value=" "></option>
                                            <option value="BROCO ">BROCO</option>
                                            <option value="ETERNA ">ETERNA</option>
                                        </Select> </td>
                                    <td> <input type="text " class="form-control form-control-sm text-right "
                                            name="price " id="price " placeholder="Price " value="0 "> </td>
                                    <td> <input type="text " class="form-control form-control-sm text-right "
                                            name="qty " id="qty " placeholder="Qty " value="0 "> </td>
                                    <td> <Select class=" form-control form-control-sm " id="unit-888">
                                            <option value=" "></option>
                                            <option value="BROCO ">pcs</option>
                                            <option value="ETERNA ">mtr</option>
                                            <option value="ETERNA ">roll</option>
                                        </Select> </td>
                                    <td> <input type="text " class="form-control form-control-sm text-right "
                                            name="disc " id="disc " placeholder="Disc " value="0 "> </td>
                                    <td> <input type="text " class="form-control form-control-sm text-right "
                                            name="ammount " id="ammount " placeholder="Amount " value="0 "
                                            disabled>
                                    </td>
                                </tr>
                            </tbody> {{-- footer --}} {{-- tfoot without bo --}} <tfoot>
                                <tr>
                                    <td colspan="7 " class="text-right  ">Sub Total</td>
                                    <td class="text-right "> <input type="text "
                                            class="form-control form-control-sm text-right " name="sub_total "
                                            id="sub_total " placeholder="Sub Total " value="0 "
                                            style="background-color: cyan; font-weight: bold " disabled> </td>
                                </tr>
                                <tr>
                                    <td colspan="7 " class="text-right ">Discount</td>
                                    <td class="text-right "> <input type="text "
                                            class="form-control form-control-sm text-right " name="discount "
                                            id="discount " placeholder="Discount " value="0 "
                                            style="background-color: cyan; font-weight: bold " disabled> </td>
                                </tr>
                                <tr>
                                    <td colspan="7 " class="text-right ">Total</td>
                                    <td class="text-right "> <input type="text "
                                            class="form-control form-control-sm text-right " name="total "
                                            id="total " placeholder="Total " value="0 "
                                            style="background-color: cyan; font-weight: bold " disabled>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

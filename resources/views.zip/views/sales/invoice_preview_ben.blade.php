<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{ asset('') }}assets/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
    <link rel="stylesheet" href="{{ asset('assets/dist/css/adminlte.min.css') }}">
    <title>Document</title>
</head>

<body>

    <div class="col-12 invoice p-3 mb-3">


        <div class="row" id="pdf-page">
            <div class="col-8 mt-1">
                <h4>
                    <div class="row justify-content-center">
                        <img src="{{ asset('') }}assets/dist/img/logo_etn.png" alt="logo" class="brand-image "
                            style="opacity: .8" height="100" width="100">
                        <div class="col justify-content-center flex-column">
                            Eza Teknologi Nusantara <br>
                            <h6>
                                Mechanical, Electrical & IT Solutions <br>
                                Jl. Cut Nyak Dhien (Sebelah Utara Kampus Uniku 1) <br>
                                Cijoho, Kuningan - Jawa Barat 45571 <br>
                                0232 -890 2107 / sales@etn.co.id
                            </h6>

                        </div>

                    </div>

                </h4>
            </div>
            <div class="col-4 mt-1 text-right">
                <h4>
                    <strong>
                        #{{ $invoice['invoice_number'] }}
                    </strong>
                </h4>
                {{-- PAID --}}
                <h3>
                    <span class="badge badge-success">Paid</span>
                </h3>



            </div>




        </div>


        <div class="row invoice-info">
            <div class="col-8 invoice-col">
                <h5>Invoiced to :
                </h5>
                <address>

                    <h6>
                        {{ $company['name'] }} <br>
                        Attn: {{ $customer['name'] }}<br>
                        {{ $customer['address'] }}<br>
                        {{ $customer['city'] }}, {{ $customer['state'] }} {{ $customer['zip_code'] }}<br>
                        Phone: {{ $customer['phone'] }}<br>
                        {{-- Email: mailto --}}
                        Email: {{ $customer['email'] }}
                    </h6>
                </address>
            </div>


            <div class="col-4 invoice-col">
                <h5>Details :</h5>
                <h6>
                    Quotation # : On Call<br>
                    Invoice # : {{ $invoice['invoice_number'] }}<br>
                    Job Date : {{ $invoice['job_date'] }}<br>
                    Invoice Date :</b> {{ $invoice['date'] }}<br>
                    Due Date : {{ $invoice['due_date'] }}<br>
                </h6>
            </div>




        </div>


        <div class="row invoice-info mb-2">
            <div class="col-8 invoice-col">
                {{-- h5 underline text --}}
                <h6>
                    <u>
                        <strong>
                            {{ $invoice['title'] }}
                        </strong>
                    </u>
                </h6>

            </div>
            <div class="col-4 invoice-col ">
                <h5>

                    Invoice Total (IDR) :
                    {{ number_format($invoice['total'], 2, ',', '.') }}
                </h5>
            </div>
        </div>




        <div class="row" id="table_container">
            <div class="col-12 table-responsive">
                @foreach ($invoice_details as $card)
                    <table class="table table-bordered table-sm" id="{{ $card['subid'] }}">
                        <thead style="background-color: rgb(218, 230, 230)">
                            <tr class="text-center">
                                <th width="35% ">Name</th>
                                <th width="10% ">Type</th>
                                <th width="10% ">Brand</th>
                                <th width="10% ">Price (IDR)</th>
                                <th width="5% ">Qty</th>
                                <th width="5% ">Unit</th>
                                <th width="5% ">Disc(%)</th>
                                <th width="10% ">Amount (IDR)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <td colspan="8">
                                <strong>{{ $card['sub_title'] }}</strong>
                            </td>
                            @foreach ($card['details'] as $item)
                                <tr id="item">
                                    <td class="p-2">
                                        {{ $item['name'] }}
                                        @if ($item['note'] != null)
                                            <br>
                                            {!! $item['note'] !!}
                                        @endif
                                    </td>
                                    <td class="text-center p-2" style="vertical-align:top">{{ $item['type'] }}</td>
                                    <td class="text-center p-2" style="vertical-align:top">{{ $item['brand'] }}</td>
                                    <td class="text-right p-2" style="vertical-align:top">
                                        {{ number_format($item['price'], 2, ',', '.') }}</td>
                                    <td class="text-center p-2" style="vertical-align:top" id="unit">
                                        {{ $item['qty'] }}
                                    </td>
                                    <td class="text-center p-2" style="vertical-align:top">{{ $item['unit'] }}</td>
                                    <td class="text-center p-2" style="vertical-align:top" id="discount">
                                        {{ $item['discount_value'] }}
                                    </td>
                                    <td class="text-right p-2" style="vertical-align:top" id="ammount"
                                        value="{{ $item['ammount'] }}">
                                        {{ number_format($item['ammount'], 2, ',', '.') }}</td>
                                </tr>
                            @endforeach

                        <tfoot>
                            <tr>
                                <td colspan="7 " class="text-right  "><strong>Total Before Discount (IDR)</strong>
                                </td>
                                <td class="text-right p-2 "
                                    style="background-color: rgb(177, 239, 255);font-weight:bold "
                                    id="discount_{{ $card['subid'] }}">
                                    <strong>{{ number_format($card['sub_total'], 2, ',', '.') }}</strong>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="7 " class="text-right  "><strong>Discount (IDR)</strong> </td>
                                <td class="text-right p-2 " style="background-color: rgb(177, 239, 255)"
                                    id="discount_{{ $card['subid'] }}">
                                    <strong>{{ number_format($card['discount'], 2, ',', '.') }}</strong>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="7 " class="text-right  "><strong>Total (IDR)</strong> </td>
                                <td class="text-right p-2 " style="background-color: rgb(177, 239, 255)"
                                    id="total_{{ $card['subid'] }}">
                                    <strong>{{ number_format($card['total'], 2, ',', '.') }}</strong>
                                </td>
                            </tr>
                        </tfoot>


                        </tbody>
                    </table>
                @endforeach


            </div>

        </div>

        <div class="row">

            <div class="col-7">
                <p class="lead">Notes:</p>
                <p class="text-muted well well-sm shadow-none">
                <ul>
                    <li>Barang yang sudah dibeli tidak dapat dikembalikan</li>
                    <li>Kelebihan material (jika ada) akan dikembalikan kepihak pembeli</li>
                    <li>Garansi barang mengikuti garansi resmi distributor</li>
                    <li>Garansi instalasi selama 1 bulan</li>
                </ul>


            </div>


            <div class=" col-5">
                {{-- <p class="lead">Amount Due 2/22/2014</p> --}}
                <div class="table-responsive">
                    <table class="table table-sm">
                        <tr>
                            <th>
                                <h6>Total Before Discount (IDR)</h6>
                            </th>
                            <td class="text-right">
                                <h6> {{ number_format($invoice['subtotal'], 2, ',', '.') }}</h6>
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <h6>Discount Total (IDR)</h6>
                            </th>
                            <td class="text-right">
                                <h6> {{ number_format($invoice['discount_value'], 2, ',', '.') }}</h6>
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <h6> Shipping (IDR)</h6>
                            </th>
                            <td class="text-right">
                                <h6> 0.00</h6>
                            </td>
                        </tr>
                        <tr>
                            <th>
                                <h6>Grand Total (IDR)</h6>
                            </th>
                            <td class="text-right">
                                <h4> <b> {{ number_format($invoice['total'], 2, ',', '.') }}</b></h4>
                            </td>

                        </tr>

                    </table>

                </div>
            </div>

        </div>

    </div>
    <script>
        // window.print with all css
        window.onload = function() {
            // print
            window.print();

        }
    </script>

</body>

</html>

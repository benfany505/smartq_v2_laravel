@extends('layouts.master')
@section('title', 'ETN | Invoice')
@push('custom-css')
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet"
        href="{{ asset('') }}assets/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="{{ asset('') }}assets/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- JQVMap -->
    <link rel="stylesheet" href="{{ asset('') }}assets/plugins/jqvmap/jqvmap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="{{ asset('') }}assets/dist/css/adminlte.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="{{ asset('') }}assets/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="{{ asset('') }}assets/plugins/daterangepicker/daterangepicker.css">
    <!-- summernote -->
    <link rel="stylesheet" href="{{ asset('') }}assets/plugins/summernote/summernote-bs4.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href=" {{ asset('') }}assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet"
        href=" {{ asset('') }}assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href=" {{ asset('') }}assets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
@endpush
@section('content')

    {{-- add card left col-8 right col-4 --}}
    <form id="form-1">
        @csrf
        <div class=" container-fluid">
            <div class="col-md-12 " id="mainContainer">
                <div class="card card-info">
                    <div class="card-header">
                        <h3 class="card-title">Quotation Header</h3>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="ribbon-wrapper  ribbon-lg">
                                <div class="ribbon bg-secondary text-lg" id="ribbon">
                                    Ribbon
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group row">
                                    <label for="customer" class="col-sm-2 col-form-label  ">Customer</label>
                                    <div class="col-sm-10">
                                        <Select class="select-inmodal form-control" id="customer" required>
                                            <option value=""></option>

                                            {{-- @foreach ($customers as $customer)
                                                <option value="{{ $customer->id }}">{{ $customer->name }}</option>
                                            @endforeach --}}
                                        </Select>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="address" class="col-sm-2 col-form-label  ">Address</label>
                                    <div class="col-sm-10">
                                        {{-- textarea for address disabled column phone address --}}
                                        <textarea class="form-control" id="address" rows="3" readonly style="resize: none; overflow: hidden;">
                                            
                                        </textarea>

                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="title" class="col-sm-2 col-form-label  ">Title</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control form-control-sm" id="title"
                                            name="title" required>
                                    </div>
                                </div>



                            </div>
                            <div class="col-sm-3">

                                <div class="form-group row">
                                    <label for="inv_date" class="col-sm-3 col-form-label ">Status</label>
                                    <div class="col-sm-9">
                                        <Select class="form-control form-control-sm" id="status" name="status" required>
                                            <option value=""></option>
                                            <option value="published">Published</option>
                                            <option value="draft">Draft</option>
                                        </select>


                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="inv_date" class="col-sm-3 col-form-label  ">Quot Date</label>
                                    <div class="col-sm-9">
                                        <input type="date" class="form-control form-control-sm" id="inv_date"
                                            name="inv_date" required>
                                    </div>
                                </div>
                                {{-- <div class="form-group row">
                                    <label for="job_date" class="col-sm-3 col-form-label  ">Job Date</label>
                                    <div class="col-sm-9">
                                        <input type="date" class="form-control form-control-sm" id="job_date"
                                            name="job_date" required>
                                    </div>
                                </div> --}}
                                <div class="form-group row">
                                    <label for="due_date" class="col-sm-3 col-form-label  ">Exp Date</label>
                                    <div class="col-sm-9">
                                        <input type="date" class="form-control form-control-sm" id="due_date"
                                            name="due_date" required>
                                    </div>
                                </div>

                            </div>
                            <div class="col-sm-3">
                                {{-- sub total sub_discount_value grand total --}}
                                {{-- <div class="form-group row">
                                    <label for="inv_date" class="col-sm-3 col-form-label  ">Quot #</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control form-control-sm" id="quot"
                                            name="quot" required>
                                    </div>
                                </div> --}}
                                <div class="form-group row">
                                    <label for="sub_total" class="col-sm-4 col-form-label  ">Sub Total</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control form-control-sm text-right"
                                            id="sub_total_header" name="sub_total"
                                            style="background-color: cyan; font-weight: bold" disabled>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="sub_discount_value" class="col-sm-4 col-form-label  ">Sub Discount</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control  form-control-sm text-right"
                                            id="sub_discount_header" name="sub_discount_value"
                                            style="background-color: cyan; font-weight: bold" disabled>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="discount_value" id="lableDiscount"
                                        class="col-sm-4 col-form-label  ">Discount</label>
                                    <div class="col-sm-8 input-group">

                                        <div class="input-group-prepend">
                                            <button type="button" class="btn btn-danger btn-sm  form-control-sm"
                                                id="setDiscount" data-toggle="modal"
                                                data-target="#setDiscountModal">Set</button>
                                        </div>
                                        <input type="text" class="form-control  form-control-sm text-right"
                                            id="discount_value_header" name="discount_value"
                                            style="background-color: cyan; font-weight: bold" disabled>
                                    </div>

                                </div>
                                <div class="form-group row">
                                    <label for="grand_total" class="col-sm-4 col-form-label  ">Grand Total</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control form-control-sm text-right"
                                            id="grand_total_header" name="grand_total"
                                            style="background-color: cyan; font-weight: bold" disabled>
                                    </div>
                                </div>

                            </div>

                        </div>



                    </div>
                </div>
                <div class="row pt-2" id="header">
                    <div class="col-sm-6">
                        <div class="card card-info">
                            <div class="card-header">
                                <h3 class="card-title">Header</h3>
                            </div>
                            <div class="card-body">
                                <div class="row">

                                    <div class="col-sm-12">
                                        <textarea class="form-control" id="headers" rows="3" style="resize: none; overflow: hidden;">                                                
                                            </textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="card card-info">
                            <div class="card-header">
                                <h3 class="card-title">Footer</h3>
                            </div>
                            <div class="card-body">
                                <div class="row">

                                    <div class="col-sm-12">
                                        <textarea class="form-control" id="footers" rows="3" style="resize: none; overflow: hidden;">                                                
                                            </textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            {{-- header and footer summernote --}}

            {{-- end header and footer summernote --}}
            <div class="row" id="footerButton">
                <div class="col-sm-12 mr-2">
                    <button type="submit" class="btn btn-primary float-right mr-2" id="button_save">Save</button>
                    <button type="button" class="btn btn-success float-right mr-2" id="add_sub">Add Sub</button>
                </div>
            </div>

            {{-- modal set sub_discount_value with option % or total --}}
            <div class="modal fade" id="setDiscountModal" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Set Discount</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">

                            <div class="form-group row">
                                <label for="discount_type" class="col-sm-3 col-form-label  ">Discount Type</label>
                                <div class="col-sm-9">
                                    <Select class="form-control form-control-sm" id="discount_type" name="discount_type">
                                        <option value="not_applied">Not Applied</option>
                                        <option value="percent">Percent</option>
                                        <option value="total">Total</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="sub_discount_value" class="col-sm-3 col-form-label  ">Discount</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control  form-control-sm text-right"
                                        id="set_discount_value" name="sub_discount" style=" font-weight: bold" disabled>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary" id="setDiscountButton"
                                data-dismiss="modal">Set</button>
                        </div>
                    </div>
                </div>
            </div>

            {{-- header and footer summernote --}}
            <div class="row pt-2" id="footer">
                <div class="col-sm-12">
                    <div class="card card-info">
                        <div class="card-header">
                            <h3 class="card-title">Notes</h3>
                        </div>
                        <div class="card-body">
                            <div class="row">

                                <div class="col-sm-12">
                                    <textarea class="form-control" id="notes" rows="3" style="resize: none; overflow: hidden;">                                                
                                            </textarea>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {{-- end header and footer summernote --}}



        </div>
    </form>

    {{-- modal find item --}}
    <div class="modal fade" id="modal_find_item" tabindex="-1" role="dialog" aria-labelledby="modal_find_item"
        aria-hidden="true">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modal_find_item">Find Item</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="card-body table-responsive">
                        <table id="table_find" class="table text-nowrap table-bordered table-striped table-sm">
                            <thead class="table-primary">
                                <tr class="text-center">
                                    <th width="5%">#</th>
                                    <th width="43%">Name</th>
                                    <th width="15%">Type</th>
                                    <th width="10%">Brand</th>
                                    <th width="10%">Price (IDR)</th>
                                    <th width="5%">Unit</th>
                                    <th width="7%">Action</th>

                                </tr>
                            </thead>
                            <tbody>


                            </tbody>

                        </table>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>










@endsection
@push('custom-js')
    <!-- jQuery UI 1.11.4 -->
    <script src="{{ asset('') }}assets/plugins/jquery-ui/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
        $.widget.bridge('uibutton', $.ui.button)
    </script>
    <!-- Bootstrap 4 -->
    <script src="{{ asset('') }}assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- ChartJS -->
    <script src="{{ asset('') }}assets/plugins/chart.js/Chart.min.js"></script>
    <!-- Sparkline -->
    <script src="{{ asset('') }}assets/plugins/sparklines/sparkline.js"></script>
    <!-- JQVMap -->
    <script src="{{ asset('') }}assets/plugins/jqvmap/jquery.vmap.min.js"></script>
    <script src="{{ asset('') }}assets/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
    <!-- jQuery Knob Chart -->
    <script src="{{ asset('') }}assets/plugins/jquery-knob/jquery.knob.min.js"></script>
    <!-- daterangepicker -->
    <script src="{{ asset('') }}assets/plugins/moment/moment.min.js"></script>
    <script src="{{ asset('') }}assets/plugins/daterangepicker/daterangepicker.js"></script>
    <!-- Tempusdominus Bootstrap 4 -->
    <script src="{{ asset('') }}assets/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
    <!-- Summernote -->
    <script src="{{ asset('') }}assets/plugins/summernote/summernote-bs4.min.js"></script>
    <!-- overlayScrollbars -->
    <script src="{{ asset('') }}assets/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
    <!-- DataTables  & Plugins -->
    <script src=" {{ asset('') }}assets/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/jszip/jszip.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/pdfmake/pdfmake.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/pdfmake/vfs_fonts.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-buttons/js/buttons.print.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>


    {{-- script before initialize modal --}}
    <script>
        $(document).ready(function() {
            $('#discount_value_header').val(0);

            // #setDiscountButton on click
            $('#setDiscountButton').click(function() {

                if ($('#discount_type').val() == 'total') {
                    // #discount_value == #set_discount_value
                    $('#discount_value_header').val($('#set_discount_value').val());
                    recalculateGt();
                    $('#lableDiscount').text('Discount (IDR)');
                } else if ($('#discount_type').val() == 'percent') {
                    $('#discount_value_header').val(0);
                    recalculateGt();
                    $('#lableDiscount').text('Discount (' + $('#set_discount_value').val() + '%)');
                } else {
                    $('#discount_value_header').val(0);
                    recalculateGt();
                    $('#lableDiscount').text('Discount');
                }

            });

            $('#discount_type').change(function() {
                if ($(this).val() == 'percent') {
                    $('#set_discount_value').val(0);
                    $('#set_discount_value').prop('disabled', false);
                    $('#set_discount_value').focus();
                    // add #lableDiscount (%)

                } else if ($(this).val() == 'total') {
                    $('#set_discount_value').val(0);
                    $('#set_discount_value').prop('disabled', false);
                    $('#set_discount_value').focus();

                } else if ($(this).val() == 'not_applied') {
                    console.log('not_applied');
                    $('#set_discount_value').prop('disabled', true);
                    $('#set_discount_value').val('');

                }
            });

            // #discount_value only number
            $('#set_discount_value').keypress(function(e) {
                // allow number and dot only
                if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                    // allow dot
                    if (e.which == 46) {
                        return true;
                    } else {
                        return false;
                    }
                }

            });

            // #discount_value on keyup
            $('#set_discount_value').keyup(function() {
                if ($('#discount_type').val() == 'percent') {
                    //    maximum 100
                    if ($(this).val() > 100) {
                        $(this).val(100);

                    }

                } else if ($('#discount_type').val() == 'total') {
                    var val = $(this).val();
                    val = val.toString().replace(/,/g, "");
                    val = val.split('').reverse().join('').replace(/(?=\d*\.?)(\d{3})/g, '$1,');
                    val = val.split('').reverse().join('').replace(/^[\,]/, '');
                    $(this).val(val);



                }
            });

            function changeToNumberFormat(value) {
                return value.val().replace(/\D/g, '').replace(
                    /\B(?=(\d{3})+(?!\d))/g, ",");
            }

            function recalculateGt() {

                // find id sub_total_header in #mainContainer
                var subTtlHeader = $('#sub_total_header');
                var subDiscTtlHeader = $('#sub_discount_header');
                var grandTtlHeader = $('#grand_total_header');
                var discHeader = $('#discount_value_header');

                // sum all #total in #mainContainer table
                var subTtl = 0;
                var subDiscTtl = 0;
                var grandTtl = 0;
                $('#mainContainer table').each(function() {
                    subTtl += parseFloat($(this).find('#sub_total').val()
                        .replace(
                            /[^0-9\-]+/g, ""));
                    subDiscTtl += parseFloat($(this).find('#sub_discount_value').val()
                        .replace(
                            /[^0-9\-]+/g, ""));
                    grandTtl += parseFloat($(this).find('#total').val()
                        .replace(
                            /[^0-9\-]+/g, ""));
                });
                var discValue = 0;




                if ($('#discount_type').val() == 'total') {
                    // 100,000.50 -> 100000.50
                    discValue = parseFloat($('#discount_value_header').val()
                        .replace(
                            /,(?=.*\.\d+)/g, ''));
                    // discValue = parseFloat(discValue.toFixed(2));

                } else if ($('#discount_type').val() == 'percent') {
                    discValue = (parseFloat($('#set_discount_value').val()) / 100) * grandTtl;
                    discValue = parseFloat(discValue.toFixed(2));
                    $('#discount_value_header').val(discValue.toString().replace(
                        /\B(?=(\d{3})+(?!\d))/g, ","));

                }
                console.log("subTtl: " + subTtl);
                console.log("subDiscTtl: " + subDiscTtl);
                console.log("discValue: " + discValue);
                console.log("grandTtl: " + grandTtl);
                console.log(discValue);
                grandTtl -= discValue;
                subTtlHeader.val(subTtl.toString().replace(
                    /\B(?=(\d{3})+(?!\d))/g, ","));
                subDiscTtlHeader.val(subDiscTtl.toString().replace(
                    /\B(?=(\d{3})+(?!\d))/g, ","));
                grandTtlHeader.val(grandTtl.toString().replace(
                    /\B(?=(\d{3})+(?!\d))/g, ","));
            }
            $('#ribbon').hide();

            $('#footers, #headers, #notes').summernote({
                placeholder: 'Enter your note here...',
                tabsize: 1,
                height: 100,
                autoHeight: true,
                disableDragAndDrop: true,
                lineHeights: ['0.2', '0.3', '0.4', '0.5', '0.6', '0.8', '1.0', '1.2', '1.4',
                    '1.5', '2.0',
                    '3.0'
                ],
                tabDisable: true,
                toolbar: [
                    ['fontsize', ['fontsize']],
                    ['font', ['bold', 'underline', 'clear']],
                    ['color', ['color']],
                    ['para', ['ul', 'ol', 'paragraph']],
                    ['view', ['fullscreen', 'codeview']],
                    ['insert', ['link', 'table', 'hr']],




                ]
            });

            $('#status').change(function() {
                if ($(this).val() == '') {
                    $('#ribbon').hide();
                } else {
                    $('#ribbon').hide();
                    $('#ribbon').show('slow');
                    // change to selected option text
                    $('#ribbon').text($(this).find('option:selected').text());
                    // check if selected text = 'published'
                    if ($(this).find('option:selected').text() == 'Published') {
                        $('#ribbon').addClass('bg-success');
                        $('#ribbon').removeClass('bg-secondary');
                    } else {
                        $('#ribbon').addClass('bg-secondary');
                        $('#ribbon').removeClass('bg-success');
                    }



                }
            });

            var iCard = 0;
            // get brand list from api
            var brands = [];
            var units = [];
            var customers = [];
            var itemsAndServices = [];

            // ajax get with bearer token and params
            //   $customers = Customer::orderBy('name', 'asc')->get(); 

            // wait until all data is loaded

            $.ajax({
                url: "api/quotations/data",
                type: "GET",
                data: {
                    "requestoremail": "{{ Auth::user()->email }}",

                },
                dataType: "json",
                beforeSend: function(xhr) {
                    xhr.setRequestHeader("Authorization", "Bearer " +
                        '{{ session()->get('tokenJwt') }}');
                },

                success: function(response) {
                    datas = response.data;
                    console.log(datas);
                    brands = datas.brands;
                    units = datas.units;
                    customers = datas.customers;
                    itemsAndServices = datas.products;

                    $.each(customers, function(index, value) {
                        $('#customer').append(
                            '<option value="' + value.id + '">' + value.company + " | " +
                            value
                            .name + '</option>'
                        );
                    });

                    $.each(itemsAndServices, function(index, value) {
                        // check if value.id_item key is exist
                        if (value.id_item == null) {
                            value.id_item = value.id_service

                        }
                        $('#table_find').append(
                            '<tr>' +
                            '<td>' + value.id_item + '</td>' +
                            '<td>' + value.name + '</td>' +
                            '<td>' + value.type + '</td>' +
                            '<td>' + value.brand + '</td>' +
                            '<td>' + value.price + '</td>' +
                            '<td>' + value.unit + '</td>' +
                            '<td class="text-center">' +
                            '<button class="btn btn-primary btn-xs" id="addClick" >Add</button>' +
                            '</td>' +
                            '</tr>'
                        );

                    });
                    $('#table_find').DataTable({
                        "paging": true,
                        "lengthChange": true,
                        "searching": true,
                        "ordering": true,
                        "info": true,
                        "autoWidth": false,
                        "responsive": true,
                    });



                },
                error: function(error) {
                    console.log(error);
                }
            });




            // on select customer fill textarea with customer address
            $('#customer').on('change', function() {
                console.log($(this).val());
                var customer_id = $(this).val();
                var customer_address = '';
                $('#address').text("AAA");
                $.each(customers, function(index, value) {
                    if (value.id == customer_id) {
                        console.log('sama');
                        customer_address += value.address + ", " + value.city + "\n";
                        customer_address += value.state + ", " + value.country + ", " + value
                            .zip_code + "\n";
                        customer_address += value.phone + " | " + value.email + "\n";
                    }
                });
                $('#address').text(customer_address);

            });



            $('#add_sub').click(function(e) {
                e.preventDefault();
                iCard++;
                var summernoteCard =
                    '<div class="card card-info " id="card-' + iCard + '">' +
                    '                    <div class="card-header ">' +
                    '                        <h3 class="card-title ">Quotation Details #' + iCard +
                    ' </h3>' +
                    '                    </div>' +
                    '                    <div class="card-body " id="sub_items"> {{-- button add sub group --}} <div class="row ">' +
                    '                            <div class="col-sm-12 table-responsive ">' +
                    '                                <div class="row ">' +
                    '                                    <div class="col-sm-5 mb-2 "> <input type="text " class="form-control form-control-sm "' +
                    '                                            name="sub_title " id="sub_title" placeholder="Sub Title " required> </div>' +
                    '                                    <div class="col-sm-4 mb-2  "> <button type="button " class="btn btn-sm btn-primary "' +
                    '                                            id="add_blank_line-' + iCard +
                    '"> <i class="      fas fa-plus "></i> Add Line' +
                    '                                        </button>' +
                    '                                        <button type="button " class="btn btn-sm btn-success " id="find_product-' +
                    iCard + '"> <i' +
                    '                                                class="fas fa-search "></i> Find Products </button> <button type="button "' +
                    '                                            class="btn btn-sm btn-danger " id="delete_card-' +
                    iCard + '"> <i' +
                    '                                                class="fas fa-trash "></i>' +
                    '                                            Remove Sub </button> {{-- delete --}}' +
                    '                                    </div>' +
                    '                                    {{-- sub total text right --}} {{-- small button add row --}}' +
                    '                                </div>' +
                    '                                <div class="row ">' +
                    '                                    <div class="col-sm-12 ">' +
                    '                                        <table class="table text-nowrap table-bordered table-striped table-sm " id="table-' +
                    iCard + '">' +
                    '                                            <thead class="table-primary ">' +
                    '                                                <tr class="text-center ">' +
                    '                                                    <th width="35% ">Name</th>' +
                    '                                                    <th width="10% ">Type</th>' +
                    '                                                    <th width="10% ">Brand</th>' +
                    '                                                    <th width="10% ">Price (IDR)</th>' +
                    '                                                    <th width="5% ">Qty</th>' +
                    '                                                    <th width="5% ">Unit</th>' +
                    '                                                    <th width="5% ">Disc(%)</th>' +
                    '                                                    <th width="10% ">Amount (IDR)</th>' +
                    '                                                </tr>' +
                    '                                            </thead>' +
                    '                                            <tbody>' +
                    // '                                                <tr>' +
                    // '                                                    <td style="vertical-align:top">' +
                    // '                                                        <div class="input-group ">' +
                    // '                                                            <div class="col m-0 p-0">' +
                    // '                                                                <div class="input-group">' +
                    // '                                                                    <button type="button " class="btn btn-danger btn-xs "' +
                    // '                                                                        id="delete_row"><i' +
                    // '                                                                            class="fa fa-trash text-xs "></i>' +
                    // '                                                                    </button>' +
                    // '                                                                    <input type="text "' +
                    // '                                                                        class="form-control form-control-sm  " name="name "' +
                    // '                                                                        id="name" placeholder="Name ">' +
                    // '                                                                    <button type="button" class="btn btn-info btn-xs "' +
                    // '                                                                        id="edit_note"><i id="icon_note"' +
                    // '                                                                            class="fas fa-edit text-xs "></i>' +
                    // '                                                                    </button>' +
                    // '' +
                    // '                                                                </div>' +
                    // '' +
                    // '                                                                {{-- summernote --}}' +
                    // '                                                                <div class="row" id="note">' +
                    // '                                                                    <div class="col-sm-12 ">' +
                    // '                                                                        <textarea class="form-control" name="note " id="summernote" rows="3 " placeholder="Note" style="display: none;"></textarea>' +
                    // '                                                                    </div>' +
                    // '                                                                </div>' +
                    // '' +
                    // '' +
                    // '' +
                    // '                                                            </div>' +
                    // '' +
                    // '                                                        </div>' +
                    // '                                                    </td>' +
                    // '                                                    <td style="vertical-align:top"> <input type="text " class="form-control form-control-sm "' +
                    // '                                                            name="name " id="type" placeholder="Type "> </td>' +
                    // '                                                    <td style="vertical-align:top"> <Select class=" form-control form-control-sm " id="brand-' +
                    // iCard + '">' +
                    // '                                                            <option value=" "></option>' +
                    // '                                                            <option value="BROCO ">BROCO</option>' +
                    // '                                                            <option value="ETERNA ">ETERNA</option>' +
                    // '                                                        </Select> </td>' +
                    // '                                                    <td style="vertical-align:top"> <input type="text "' +
                    // '                                                            class="form-control form-control-sm text-right " name="price "' +
                    // '                                                            id="price" placeholder="Price " value="0 "> </td>' +
                    // '                                                    <td style="vertical-align:top"> <input type="text "' +
                    // '                                                            class="form-control form-control-sm text-right " name="qty"' +
                    // '                                                            id="qty" placeholder="Qty " value="0 "> </td>' +
                    // '                                                    <td style="vertical-align:top"> <Select class=" form-control form-control-sm " id="unit-' +
                    // iCard + '">' +
                    // '                                                            <option value=" "></option>' +
                    // '                                                            <option value="BROCO ">pcs</option>' +
                    // '                                                            <option value="ETERNA ">mtr</option>' +
                    // '                                                            <option value="ETERNA ">roll</option>' +
                    // '                                                        </Select> </td>' +
                    // '                                                    <td style="vertical-align:top"> <input type="text "' +
                    // '                                                            class="form-control form-control-sm text-right " name="item_discount "' +
                    // '                                                            id="item_discount" placeholder="Disc " value="0 "> </td>' +
                    // '                                                    <td style="vertical-align:top"> <input type="text "' +
                    // '                                                            class="form-control form-control-sm text-right " name="ammount "' +
                    // '                                                            id="ammount" placeholder="Amount " value="0 " disabled>' +
                    // '                                                    </td>' +
                    // '                                                </tr>' +
                    '                                            </tbody> {{-- footer --}} {{-- tfoot without bo --}} <tfoot>' +
                    '                                                <tr>' +
                    '                                                    <td colspan="7 " class="text-right  ">Sub Total</td>' +
                    '                                                    <td class="text-right "> <input type="text "' +
                    '                                                            class="form-control form-control-sm text-right "' +
                    '                                                            name="sub_total " id="sub_total" placeholder="Sub Total "' +
                    '                                                            value="0 " style="background-color: cyan; font-weight: bold "' +
                    '                                                            disabled> </td>' +
                    '                                                </tr>' +
                    '                                                <tr>' +
                    '                                                    <td colspan="7 " class="text-right ">Discount</td>' +
                    '                                                    <td class="text-right "> <input type="text "' +
                    '                                                            class="form-control form-control-sm text-right "' +
                    '                                                            name="sub_discount_value " id="sub_discount_value" placeholder="Discount "' +
                    '                                                            value="0 " style="background-color: cyan; font-weight: bold "' +
                    '                                                            disabled> </td>' +
                    '                                                </tr>' +
                    '                                                <tr>' +
                    '                                                    <td colspan="7 " class="text-right ">Total</td>' +
                    '                                                    <td class="text-right "> <input type="text "' +
                    '                                                            class="form-control form-control-sm text-right " name="total "' +
                    '                                                            id="total" placeholder="Total " value="0 "' +
                    '                                                            style="background-color: cyan; font-weight: bold " disabled>' +
                    '                                                    </td>' +
                    '                                                </tr>' +
                    '                                            </tfoot>' +
                    '                                        </table>' +
                    '                                    </div>' +
                    '                                </div>' +
                    '                            </div>' +
                    '                        </div>' +
                    '                    </div>' +
                    '                </div>' +
                    '';
                var newCard =
                    "<div class=\"card card-info\" id=\"card-" +
                    iCard +
                    "\">\n                    <div class=\"card-header\">\n                        <h3 class=\"card-title\">Quotation Details #" +
                    iCard +
                    "</h3>\n                    </div>\n                    <div class=\"card-body\" id=\"sub_items\">\n                        {{-- button add sub group --}}\n                        <div class=\"row\">\n                            <div class=\"col-sm-12 table-responsive\">\n                                <div class=\"row\">\n                                    <div class=\"col-sm-5 mb-2\">\n                                        <input type=\"text\" class=\"form-control form-control-sm\" name=\"sub_title\"\n                                            id=\"sub_title\" placeholder=\"Sub Title\">\n                                    </div>\n                                    <div class=\"col-sm-4 mb-2 \">\n                                        <button type=\"button\" class=\"btn btn-sm btn-primary\" id=\"add_blank_line-" +
                    iCard +
                    "\">\n                                            <i class=\"fas fa-plus\"></i> Add Line\n                                        </button>\n<button type=\"button\" class=\"btn btn-sm btn-success\" id=\"find_product-" +
                    iCard +
                    "\">\n                                            <i class=\"fas fa-search\"></i> Find Products\n                                        </button>\n <button type=\"button\" class=\"btn btn-sm btn-danger\" id=\"delete_card-" +
                    iCard +
                    "\">\n                                            <i class=\"fas fa-trash\"></i> Remove Sub\n                                        </button>\n                                        {{-- delete --}}\n\n                                    </div>\n                                    {{-- sub total text right --}}\n\n\n                                    {{-- small button add row --}}\n\n                                </div>\n\n                                <div class=\"row\">\n                                    <div class=\"col-sm-12\">\n                                        <table class=\"table text-nowrap table-bordered table-striped table-sm\" id=\"table-" +
                    iCard +
                    "\">\n                                            <thead class=\"table-primary\">\n                                                <tr class=\"text-center\">\n\n                                                    <th width=\"35%\">Name</th>\n                                                    <th width=\"10%\">Type</th>\n                                                    <th width=\"10%\">Brand</th>\n                                                    <th width=\"10%\">Price (IDR)</th>\n                                                    <th width=\"5%\">Qty</th>\n                                                    <th width=\"5%\">Unit</th>\n                                                    <th width=\"5%\">Disc(%)</th>\n                                                    <th width=\"10%\">Amount (IDR)</th>\n\n                                                </tr>\n                                            </thead>\n                                            <tbody>\n                                                <tr>\n                                                    <td>\n                                                        <div class=\"input-group\">\n                                                            <button type=\"button\" class=\"btn btn-danger btn-xs\"\n                                                                id=\"delete_row\"><i class=\"fa fa-trash text-xs\"></i>\n                                                            </button>\n                                                            <input type=\"text\" class=\"form-control form-control-sm \"\n                                                                name=\"name\" id=\"name\" placeholder=\"Name\">\n                                                                                                                  </div>\n\n\n\n                                                    </td>\n                                                    <td>\n\n                                                        <input type=\"text\" class=\"form-control form-control-sm\" name=\"name\"\n                                                            id=\"type\" placeholder=\"Type\">\n\n                                                    </td>\n                                                    <td>\n                                                        <Select class=\" form-control form-control-sm\" id=\"brand-" +
                    iCard +
                    "\">\n                                                            <option value=\"\"></option>\n                                                            <option value=\"BROCO\">BROCO</option>\n                                                            <option value=\"ETERNA\">ETERNA</option>\n                                                        </Select>\n                                                    </td>\n                                                    <td>\n                                                        <input type=\"text\" class=\"form-control form-control-sm text-right\"\n                                                            name=\"price\" id=\"price\" placeholder=\"Price\" value=\"0\">\n                                                    </td>\n                                                    <td>\n                                                        <input type=\"text\" class=\"form-control form-control-sm text-right\"\n                                                            name=\"qty\" id=\"qty\" placeholder=\"Qty\" value=\"0\">\n                                                    </td>\n                                                    <td>\n                                                        <Select class=\" form-control form-control-sm\" id=\"unit-" +
                    iCard +
                    "\">\n                                                            <option value=\"\"></option>\n                                                            <option value=\"BROCO\">pcs</option>\n                                                            <option value=\"ETERNA\">mtr</option>\n                                                            <option value=\"ETERNA\">roll</option>\n                                                        </Select>\n                                                    </td>\n                                                    <td>\n                                                        <input type=\"text\" class=\"form-control form-control-sm text-right\"\n                                                            name=\"item_discount\" id=\"item_discount\" placeholder=\"Disc\" value=\"0\">\n                                                    </td>\n                                                    <td>\n                                                        <input type=\"text\" class=\"form-control form-control-sm text-right\"\n                                                            name=\"ammount\" id=\"ammount\" placeholder=\"Amount\" value=\"0\"\n                                                            disabled>\n                                                    </td>\n                                                </tr>\n                                            </tbody>\n                                            {{-- footer --}}\n                                            {{-- tfoot without bo --}}\n                                            <tfoot>\n                                                <tr>\n                                                    <td colspan=\"7\" class=\"text-right \">Sub Total</td>\n                                                    <td class=\"text-right\">\n                                                        <input type=\"text\" class=\"form-control form-control-sm text-right\"\n                                                            name=\"sub_total\" id=\"sub_total\" placeholder=\"Sub Total\"\n                                                            value=\"0\" style=\"background-color: cyan; font-weight: bold\" disabled>\n                                                    </td>\n                                                </tr>\n                                                 <tr>\n                                                    <td colspan=\"7\" class=\"text-right\">Discount</td>\n                                                    <td class=\"text-right\">\n                                                        <input type=\"text\" class=\"form-control form-control-sm text-right\"\n                                                            name=\"sub_discount_value\" id=\"sub_discount_value\" placeholder=\"Discount\" value=\"0\"\n                                                            style=\"background-color: cyan; font-weight: bold\" disabled>\n                                                    </td>\n                                                </tr>\n\n                                                <tr>\n                                                    <td colspan=\"7\" class=\"text-right\">Total</td>\n                                                    <td class=\"text-right\">\n                                                        <input type=\"text\" class=\"form-control form-control-sm text-right\"\n                                                            name=\"total\" id=\"total\" placeholder=\"Total\" value=\"0\" style=\"background-color: cyan; font-weight: bold\" disabled>\n                                                    </td>\n                                                </tr> \n                                            </tfoot>\n\n\n                                        </table>\n\n                                    </div>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n\n                </div>";


                // $('#card-' + i).hide('slow', function() {
                //     // remove card from table
                //     $(this).remove();
                // });

                $('#mainContainer').append(summernoteCard);
                // show slow
                // $("#mainContainer").find("#card-" + iCard).show('slow');

                $("#mainContainer").find("#card-" + iCard).hide().show('slow');

                $("#card-" + iCard).find('#note').hide();


                // apply summernote to textarea with id summernote
                $("#card-" + iCard).find('#summernote').summernote({
                    placeholder: 'Enter your note here...',
                    tabsize: 1,
                    height: 100,
                    autoHeight: true,
                    disableDragAndDrop: true,
                    lineHeights: ['0.2', '0.3', '0.4', '0.5', '0.6', '0.8', '1.0', '1.2', '1.4',
                        '1.5', '2.0',
                        '3.0'
                    ],
                    tabDisable: true,
                    toolbar: [
                        ['fontsize', ['fontsize']],
                        ['font', ['bold', 'underline', 'clear']],
                        ['color', ['color']],
                        ['para', ['ul', 'ol', 'paragraph']],
                        ['view', ['fullscreen', 'codeview']],
                        ['insert', ['link', 'table', 'hr']],




                    ]
                });


                // add each brands['name'] to select in table of append new card
                $('#unit-' + iCard).empty();
                $('#unit-' + iCard).append('<option value=""></option>');
                $.each(units, function(key, value) {
                    $('#unit-' + iCard).append(
                        '<option value="' + value.name + '">' + value.name + '</option>'
                    );
                });

                $('#brand-' + iCard).unbind().empty();
                $('#brand-' + iCard).unbind().append('<option value=""></option>');
                $.each(brands, function(key, value) {
                    $('#brand-' + iCard).append(
                        '<option value="' + value.name + '">' + value.name + '</option>'
                    );
                });


                $('#table-' + iCard).on('keypress', '#price, #qty, #item_discount, #ammount', function(e) {
                    var charCode = (e.which) ? e.which : e.keyCode;
                    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                        return false;
                    }
                    return true;
                });

                $('#table-' + iCard).on('input', '#price, #qty, #item_discount, #ammount', function() {
                    console.log('keyup change 1');
                    // var id = $(this).attr('id');
                    // var i = id.split('-')[1];
                    // console.log($(this).attr('id'));
                    var val = $(this).val();
                    // change to thousand separator with dot
                    $(this).val(changeToNumberFormat($(this)));
                    var thisTable = $(this).closest('table');
                    var tr = $(this).closest('tr');

                    var price = parseFloat(tr.find('#price').val().replace(/[^0-9\-]+/g,
                        ""));
                    var qty = parseFloat(tr.find('#qty').val().replace(/[^0-9\-]+/g,
                        ""));
                    var item_discount = parseFloat(tr.find('#item_discount').val()
                        .replace(/[^0-9\-]+/g,
                            ""));
                    var ammount = price * qty - (price * qty * item_discount / 100);
                    // var ammount = (price * qty) * (100 - item_discount) / 100;
                    var ammountAfter = ammount;
                    ammountAfter = ammountAfter.toString().replace(
                        /\B(?=(\d{3})+(?!\d))/g, ",");
                    tr.find('#ammount').val(ammountAfter);
                    var total = 0;
                    // get table id 

                    // console.log(table.attr('id'));
                    // total form table head named ammount
                    thisTable.find('tbody tr').each(function() {
                        // frum number format to number
                        var ammountAfter = parseFloat($(this).find('#ammount')
                            .val()
                            .replace(
                                /[^0-9\-]+/g,
                                ""));
                        total += ammountAfter;
                    });
                    // find id #sub_total in this table
                    // change to numer format in this table for id #price



                    // calculate total sub_discount_value in value not in %
                    var totalDisc = 0;
                    var ammountBefore = 0
                    thisTable.find('tbody tr').each(function() {
                        // calculate ammount before sub_discount_value
                        var price = parseFloat($(this).find('#price').val()
                            .replace(
                                /[^0-9\-]+/g, ""));
                        var qty = parseFloat($(this).find('#qty').val().replace(
                            /[^0-9\-]+/g, ""));
                        var item_discount = parseFloat($(this).find(
                                '#item_discount').val()
                            .replace(
                                /[^0-9\-]+/g, ""));
                        var ammount = price * qty - (price * qty *
                            item_discount / 100);
                        // calculate sub_discount_value
                        var item_discount = parseFloat($(this).find(
                                '#item_discount').val()
                            .replace(
                                /[^0-9\-]+/g, ""));
                        ammountBefore += price * qty

                    });
                    totalDisc = ammountBefore - total;
                    var subTtl = thisTable.find('#sub_total');
                    var subDiscTtl = thisTable.find('#sub_discount_value');


                    var totalTtl = thisTable.find('#total');
                    subTtl.val(ammountBefore.toString().replace(
                        /\B(?=(\d{3})+(?!\d))/g, ","));
                    subDiscTtl.val(totalDisc.toString().replace(
                        /\B(?=(\d{3})+(?!\d))/g, ","));
                    totalTtl.val(total.toString().replace(
                        /\B(?=(\d{3})+(?!\d))/g, ","));
                    recalculateGt();



                });

                // listen if change all input in table by other function




                $('html, body').animate({
                    scrollTop: $("#footerButton").offset().top
                }, 300);


            });

            // // fill item based on modal click addItem 
            // $('#addItem').on('click', function() {
            //     console.log('add item');
            // });


            // delete card
            $(document).on('click', '[id^="delete_card-"]', function(e) {
                e.preventDefault();

                var id = $(this).attr('id');
                var i = id.split('-')[1];
                var r = confirm(
                    "Are you sure you want to delete this Sub Group? \n All data will be lost.");

                if (r == true) {

                    e.preventDefault();
                    // hide card with animation
                    $('#card-' + i).hide('slow', function() {
                        // remove card from table
                        $(this).remove();
                        recalculateGt();
                    });




                } else {
                    return false;
                }


            });



            // document on append element
            $(document).on('click', '[id^="add_blank_line-"]', function(e) {
                e.preventDefault();

                var newRowSummernote =
                    '                                                <tr>' +
                    '                                                    <td style="vertical-align:top">' +
                    '                                                        <div class="input-group ">' +
                    '                                                            <div class="col m-0 p-0">' +
                    '                                                                <div class="input-group">' +
                    '                                                                    <button type="button " class="btn btn-danger btn-xs "' +
                    '                                                                        id="delete_row"><i' +
                    '                                                                            class="fa fa-trash text-xs "></i>' +
                    '                                                                    </button>' +
                    '                                                                    <input type="text"' +
                    '                                                                        class="form-control form-control-sm  " name="id_item " value="custom"' +
                    '                                                                        id="id_item" hidden>' +
                    '                                                                    <input type="text "' +
                    '                                                                        class="form-control form-control-sm  " name="name "' +
                    '                                                                        id="name" placeholder="Name " required>' +
                    '                                                                    <button type="button" class="btn btn-info btn-xs "' +
                    '                                                                        id="edit_note"><i id="icon_note"' +
                    '                                                                            class="fas fa-edit text-xs "></i>' +
                    '                                                                    </button>' +
                    '' +
                    '                                                                </div>' +
                    '' +
                    '                                                                {{-- summernote --}}' +
                    '                                                                <div class="row" id="note">' +
                    '                                                                    <div class="container-fluid">' +
                    '                                                                        <textarea class="form-control" name="note " id="summernote" rows="3 " placeholder="Note" style="display: none;"></textarea>' +
                    '                                                                    </div>' +
                    '                                                                </div>' +
                    '' +
                    '' +
                    '' +
                    '                                                            </div>' +
                    '' +
                    '                                                        </div>' +
                    '                                                    </td>' +
                    '                                                    <td style="vertical-align:top"> <input type="text " class="form-control form-control-sm "' +
                    '                                                            name="name " id="type" placeholder="Type" required> </td>' +
                    '                                                    <td style="vertical-align:top"> <Select class=" form-control form-control-sm " id="brand-' +
                    iCard + '" required>' +
                    '                                                            <option value=""></option>' +
                    '                                                            <option value="BROCO ">BROCO</option>' +
                    '                                                            <option value="ETERNA ">ETERNA</option>' +
                    '                                                        </Select> </td>' +
                    '                                                    <td style="vertical-align:top"> <input type="text "' +
                    '                                                            class="form-control form-control-sm text-right " name="price "' +
                    '                                                            id="price" placeholder="Price" value="0" required> </td>' +
                    '                                                    <td style="vertical-align:top"> <input type="text "' +
                    '                                                            class="form-control form-control-sm text-right " name="qty"' +
                    '                                                            id="qty" placeholder="Qty " value="0" required> </td>' +
                    '                                                    <td style="vertical-align:top"> <Select class=" form-control form-control-sm " id="unit-' +
                    iCard + '" required>' +
                    '                                                            <option value=""></option>' +
                    '                                                            <option value="BROCO ">pcs</option>' +
                    '                                                            <option value="ETERNA ">mtr</option>' +
                    '                                                            <option value="ETERNA ">roll</option>' +
                    '                                                        </Select> </td>' +
                    '                                                    <td style="vertical-align:top"> <input type="text "' +
                    '                                                            class="form-control form-control-sm text-right " name="item_discount "' +
                    '                                                            id="item_discount" placeholder="Disc " value="0" required> </td>' +
                    '                                                    <td style="vertical-align:top"> <input type="text "' +
                    '                                                            class="form-control form-control-sm text-right " name="ammount "' +
                    '                                                            id="ammount" placeholder="Amount" value="0" disabled>' +
                    '                                                    </td>' +
                    '                                                </tr>';

                var newRow =
                    "<tr>\n                                                    <td>\n                                                        <div class=\"input-group\">\n                                                            <button type=\"button\" class=\"btn btn-danger btn-xs\"\n                                                                id=\"delete_row\"><i class=\"fa fa-trash text-xs\"></i>\n                                                            </button>\n                                                            <input type=\"text\" class=\"form-control form-control-sm \"\n                                                                name=\"name\" id=\"name\" placeholder=\"Name\">\n                                                                                                        </div>\n\n\n\n                                                    </td>\n                                                    <td>\n\n                                                        <input type=\"text\" class=\"form-control form-control-sm\" name=\"name\"\n                                                            id=\"name\" placeholder=\"Name\">\n\n                                                    </td>\n                                                    <td>\n                                                        <Select class=\" form-control form-control-sm\" id=\"brand-" +
                    iCard +
                    "\">\n                                                            <option value=\"\"></option>\n                                                            <option value=\"BROCO\">BROCO</option>\n                                                            <option value=\"ETERNA\">ETERNA</option>\n                                                        </Select>\n                                                    </td>\n                                                    <td>\n                                                        <input type=\"text\" class=\"form-control form-control-sm text-right\"\n                                                            name=\"price\" id=\"price\" placeholder=\"Price\" value=\"0\">\n                                                    </td>\n                                                    <td>\n                                                        <input type=\"text\" class=\"form-control form-control-sm text-right\"\n                                                            name=\"qty\" id=\"qty\" placeholder=\"Qty\" value=\"0\">\n                                                    </td>\n                                                    <td>\n                                                        <Select class=\" form-control form-control-sm\" id=\"unit-" +
                    iCard +
                    "\">\n                                                            <option value=\"\"></option>\n                                                            <option value=\"BROCO\">pcs</option>\n                                                            <option value=\"ETERNA\">mtr</option>\n                                                            <option value=\"ETERNA\">roll</option>\n                                                        </Select>\n                                                    </td>\n                                                    <td>\n                                                        <input type=\"text\" class=\"form-control form-control-sm text-right\"\n                                                            name=\"item_discount\" id=\"item_discount\" placeholder=\"Disc\" value=\"0\">\n                                                    </td>\n                                                    <td>\n                                                        <input type=\"text\" class=\"form-control form-control-sm text-right\"\n                                                            name=\"ammount\" id=\"ammount\" placeholder=\"Amount\" value=\"0\"\n                                                            disabled>\n                                                    </td>\n                                                </tr>\n ";


                var id = $(this).attr('id');
                var i = id.split('-')[1];
                $('#table-' + i + ' tbody').append(newRowSummernote);
                // slide down the box
                $('#table-' + i + ' tr:last-child').hide().show('slow');

                // clear last select option with id unit-i
                $('#table-' + i + ' tr:last-child select[id="unit-' + i + '"]').empty();
                // add new option to last select option with id unit-i from units
                $('#table-' + i + ' tr:last-child select[id="unit-' + i + '"]').append(
                    '<option value=""></option>');
                $.each(units, function(key, value) {
                    $('#table-' + i + ' tr:last-child select[id="unit-' + i + '"]').append(
                        '<option value="' + value.name + '">' + value.name + '</option>');
                });
                // clear last select option with id brand-i
                $('#table-' + i + ' tr:last-child select[id="brand-' + i + '"]').empty();
                // add new option to last select option with id brand-i from brands
                $('#table-' + i + ' tr:last-child select[id="brand-' + i + '"]').append(
                    '<option value=""></option>');
                $.each(brands, function(key, value) {
                    $('#table-' + i + ' tr:last-child select[id="brand-' + i + '"]').append(
                        '<option value="' + value.name + '">' + value.name + '</option>');
                });

                $('#table-' + i + ' tr:last-child div[id="note"]').hide();

                $('#table-' + i + ' tr:last-child textarea[id="summernote"]').summernote({
                    placeholder: 'Enter your note here...',
                    tabsize: 1,
                    height: 100,
                    autoHeight: true,
                    lineHeights: ['0.2', '0.3', '0.4', '0.5', '0.6', '0.8', '1.0', '1.2', '1.4',
                        '1.5', '2.0',
                        '3.0'
                    ],
                    tabDisable: true,
                    // hide toolbar
                    // airMode: true,
                    toolbar: [
                        ['fontsize', ['fontsize']],
                        ['font', ['bold', 'underline']],
                        ['para', ['ul', 'ol']],
                        ['insert', ['link', 'hr']],
                    ]
                });

                // $('#table-' + i + ' tr:last-child button[id="edit_note"]').click(function() {

                //     // animate toggle #note and change icon #icon_note
                //     $('#table-' + i + ' tr:last-child div[id="note"]').slideToggle();
                //     // $('#icon_note').toggleClass('fa-pencil fa-eye');

                // });


            });

            $(document).on('click', '#edit_note', function(e) {
                e.preventDefault();
                console.log('edit note');

                var table = $(this).closest('table');
                $(this).closest('tr').find('div[id="note"]').slideToggle();
                // change icon
                $(this).closest('tr').find('i[id="icon_note"]').toggleClass('fa-pencil fa-eye');





            });


            $(document).on('click', '#delete_row', function(e) {
                // get table id
                var table = $(this).closest('table');
                // var tableId = table.attr('id');



                // alert dialog and captcha
                var r = confirm("Are you sure you want to delete this row?");

                if (r == true) {

                    e.preventDefault();
                    // anmate delete row
                    $(this).closest('tr').hide('slow', function() {
                        $(this).remove();
                        recalculate(table);
                    });

                    // $(this).closest('tr').remove();
                    // recalculate ammount




                } else {
                    return false;
                }
            });

            $(document).on('click', '[id^="find_product-"]', function(e) {
                e.preventDefault();
                console.log('find product');

                var id = $(this).attr('id');
                var i = id.split('-')[1];




                // // open modal to find item 
                $('#modal_find_item').modal('show');

                $('[id="table_find"]').unbind().on('click', '#addClick', function() {
                    console.log('addClick');
                    // get data from modal
                    var randomText = Math.random().toString(36).substring(7);
                    var item_id = $(this).closest('tr').find('td:eq(0)').text();
                    var item_name = $(this).closest('tr').find('td:eq(1)').text();
                    var item_type = $(this).closest('tr').find('td:eq(2)').text();
                    var item_brand = $(this).closest('tr').find('td:eq(3)').text();
                    var item_price = $(this).closest('tr').find('td:eq(4)').text();
                    var item_unit = $(this).closest('tr').find('td:eq(5)').text();
                    var val = item_price;
                    val = val.toString().replace(/,/g, "");
                    val = val.split('').reverse().join('').replace(/(?=\d*\.?)(\d{3})/g,
                        '$1,');
                    val = val.split('').reverse().join('').replace(/^[\,]/, '');

                    var newRowSummernote =
                        '                                                <tr>' +
                        '                                                    <td style="vertical-align:top">' +
                        '                                                        <div class="input-group ">' +
                        '                                                            <div class="col m-0 p-0">' +
                        '                                                                <div class="input-group">' +
                        '                                                                    <button type="button " class="btn btn-danger btn-xs "' +
                        '                                                                        id="delete_row"><i' +
                        '                                                                            class="fa fa-trash text-xs "></i>' +
                        '                                                                    </button>' +
                        '                                                                    <input type="text "' +
                        '                                                                        class="form-control form-control-sm  " name="id_item "' +
                        '                                                                        id="id_item" value="' +
                        item_id + '" hidden>' +

                        '                                                                    <input type="text "' +
                        '                                                                        class="form-control form-control-sm  " name="name "' +
                        '                                                                        id="name" placeholder="Name " value="' +
                        item_name + '">' +
                        '                                                                    <button type="button" class="btn btn-info btn-xs "' +
                        '                                                                        id="edit_note"><i id="icon_note"' +
                        '                                                                            class="fas fa-edit text-xs "></i>' +
                        '                                                                    </button>' +
                        '' +
                        '                                                                </div>' +
                        '' +
                        '                                                                {{-- summernote --}}' +
                        '                                                                <div class="row" id="note">' +
                        '                                                                    <div class="col-sm-12 ">' +
                        '                                                                        <textarea class="form-control" name="note " id="summernote" rows="3 " placeholder="Note" style="display: none;"></textarea>' +
                        '                                                                    </div>' +
                        '                                                                </div>' +
                        '' +
                        '' +
                        '' +
                        '                                                            </div>' +
                        '' +
                        '                                                        </div>' +
                        '                                                    </td>' +
                        '                                                    <td style="vertical-align:top"> <input type="text " class="form-control form-control-sm "' +
                        '                                                            name="name " id="type" placeholder="Type" value="' +
                        item_type + '"> </td>' +
                        '                                                    <td style="vertical-align:top"> <input class=" form-control form-control-sm " id="brand-' +
                        iCard + '" value="' + item_brand + '">' +

                        '                                                               </td>' +
                        '                                                    <td style="vertical-align:top"> <input type="text "' +
                        '                                                            class="form-control form-control-sm text-right " name="price "' +
                        '                                                            id="price" placeholder="Price " value="' +
                        val + '"> </td>' +
                        '                                                    <td style="vertical-align:top"> <input type="text "' +
                        '                                                            class="form-control form-control-sm text-right " name="qty"' +
                        '                                                            id="qty" placeholder="Qty " value="1 "> </td>' +
                        '                                                    <td style="vertical-align:top"> <input class=" form-control form-control-sm " id="unit-' +
                        iCard + '" value="' + item_unit + '">' +

                        '                                                         </td>' +
                        '                                                    <td style="vertical-align:top"> <input type="text "' +
                        '                                                            class="form-control form-control-sm text-right " name="item_discount "' +
                        '                                                            id="item_discount" placeholder="Disc " value="0"> </td>' +
                        '                                                    <td style="vertical-align:top"> <input type="text "' +
                        '                                                            class="form-control form-control-sm text-right " name="ammount "' +
                        '                                                            id="ammount" placeholder="Amount " value="' +
                        val + '" disabled>' +
                        '                                                    </td>' +
                        '                                                </tr>';


                    // append data to table
                    var newRow =
                        "<tr>\n                                                    <td>\n                                                        <div class=\"input-group\">\n                                                            <button type=\"button\" class=\"btn btn-danger btn-xs\"\n                                                                id=\"delete_row\"><i class=\"fa fa-trash text-xs\"></i>\n                                                            </button>\n                                                            <input  type=\"text\" class=\"form-control form-control-sm \"\n                                                                name=\"name\" id=\"name\" placeholder=\"Name\" value=\"" +
                        item_name +
                        "\">\n                                                                                                                    </div>\n\n\n\n                                                    </td>\n                                                    <td>\n\n                                                        <input  type=\"text\" class=\"form-control form-control-sm\" name=\"type\"\n                                                            id=\"type\" placeholder=\"Type\" value=\"" +
                        item_type +
                        "\">\n\n                                                    </td>\n                                                    <td>\n                                                        <input  type=\"text\"  class=\" form-control form-control-sm\" id=\"brand-" +
                        iCard +
                        "\" value=\"" +
                        item_brand +
                        "\">\n                                                            </td>\n                                                    <td>\n                                                        <input type=\"text\" class=\"form-control form-control-sm text-right\"\n                                                            name=\"price\" id=\"price\" placeholder=\"Price\" value=\"" +
                        val +
                        "\">\n                                                    </td>\n                                                    <td>\n                                                        <input type=\"text\" class=\"form-control form-control-sm text-right\"\n                                                            name=\"qty\" id=\"qty\" placeholder=\"Qty\" value=\"" +
                        1 +
                        "\">\n                                                    </td>\n                                                    <td>\n                                                        <Input type=\"text\" class=\" form-control form-control-sm\" id=\"unit-" +
                        iCard +
                        "\" value=\"" +
                        item_unit +
                        "\">\n                                                                                                               </td>\n                                                    <td>\n                                                        <input type=\"text\" class=\"form-control form-control-sm text-right\"\n                                                            name=\"item_discount\" id=\"item_discount\" placeholder=\"Disc\" value=\"0\">\n                                                    </td>\n                                                    <td>\n                                                        <input type=\"text\" class=\"form-control form-control-sm text-right\"\n                                                            name=\"ammount\" id=\"ammount\" placeholder=\"Amount\" value=\"" +
                        val +
                        "\"\n                                                           disabled>\n                                                    </td>\n                                                </tr>\n ";
                    $('#table-' + i + ' tbody').append(newRowSummernote);
                    $('#table-' + i + ' tr:last-child').hide().show('slow');

                    $('#table-' + i + ' tr:last-child div[id="note"]').hide();

                    $('#table-' + i + ' tr:last-child textarea[id="summernote"]').summernote({
                        placeholder: 'Enter your note here...',
                        tabsize: 1,
                        height: 100,
                        autoHeight: true,
                        disableDragAndDrop: true,
                        lineHeights: ['0.2', '0.3', '0.4', '0.5', '0.6', '0.8', '1.0',
                            '1.2', '1.4',
                            '1.5', '2.0',
                            '3.0'
                        ],
                        tabDisable: true,
                        toolbar: [
                            ['fontsize', ['fontsize']],
                            ['font', ['bold', 'underline']],
                            ['para', ['ul', 'ol']],
                            ['insert', ['link', 'hr']],
                        ]
                    });










                    // name.val(randomText);
                    // get table
                    var table = $('#table-' + i);

                    // destroy modal
                    $('#modal_find_item').modal('hide');
                    recalculate(table);

                });




            });



            // recalculate ammount and total
            function recalculate(table) {
                console.log('Recalculate : ' + table.attr('id'));
                var total = 0;
                var totalDisc = 0;
                var ammountBefore = 0
                table.find('tbody tr').each(function() {
                    // calculate ammount before sub_discount_value
                    var price = parseFloat($(this).find('#price').val().replace(
                        /[^0-9\-]+/g, ""));
                    var qty = parseFloat($(this).find('#qty').val().replace(
                        /[^0-9\-]+/g, ""));
                    var item_discount = parseFloat($(this).find('#item_discount').val().replace(
                        /[^0-9\-]+/g, ""));
                    var ammount = price * qty - (price * qty * item_discount / 100);
                    // calculate sub_discount_value
                    var item_discount = parseFloat($(this).find('#item_discount').val().replace(
                        /[^0-9\-]+/g, ""));
                    ammountBefore += price * qty
                    var ammountField = parseFloat($(this).find('#ammount').val().replace(
                        /[^0-9\-]+/g,
                        ""));
                    total += ammountField;

                });
                totalDisc = ammountBefore - total;
                var subTtl = table.find('#sub_total');
                var subDiscTtl = table.find('#sub_discount_value');
                console.log(ammountBefore);


                var totalTtl = table.find('#total');
                subTtl.val(ammountBefore.toString().replace(
                    /\B(?=(\d{3})+(?!\d))/g, ","));
                subDiscTtl.val(totalDisc.toString().replace(
                    /\B(?=(\d{3})+(?!\d))/g, ","));
                totalTtl.val(total.toString().replace(
                    /\B(?=(\d{3})+(?!\d))/g, ","));

                recalculateGt();
            };
        });
    </script>


    {{-- scrip submit fowm-1 --}}
    <script>
        const myForm = document.getElementById("form-1");
        myForm.addEventListener("submit", function(e) {
            e.preventDefault();
            var isValid = true;
            // get input form form-1 except for id #note
            var inputs = document.querySelectorAll(
                "#form-1 input:not([id^='note-'], #set_discount_value, #form-1 select)");
            for (var i = 0; i < inputs.length; i++) {
                if (inputs[i].value == "") {
                    isValid = false;
                    console.log(inputs[i]);
                }
            }
            if (isValid) {
                myForm.method = "POST";
                myForm.action = "api/quotations/create_quotation";



                // get selected select2 #customer 
                var customer = $('#customer').val();
                var address = $('#address').val();
                var quotations = $('#quot').val();
                var notes = $('#notes').val();
                var header = $('#headers').val();
                var footer = $('#footers').val();
                var title = $('#title').val();
                var status = $('#status').val();
                var inv_date = $('#inv_date').val();
                // var job_date = $('#job_date').val();
                var due_date = $('#due_date').val();
                var sub_total = parseFloat($('#sub_total_header').val().replace(/,/g, ''));
                var sub_discount_value = parseFloat($('#sub_discount_header').val().replace(/,/g, ''));
                var grand_total = parseFloat($('#grand_total_header').val().replace(/,/g, ''));
                console.log('grand_total : ' + grand_total);

                var discount_type = $('#discount_type').val();
                var discount_value = 0;
                var discount = 0;
                if ($('#discount_type').val() == 'total') {
                    discount_value = parseFloat($('#discount_value_header').val().replace(/,/g, ''));
                    discount = discount_value / (discount_value + grand_total);
                } else if ($('#discount_type').val() == 'percent') {
                    discount = parseFloat($('#set_discount_value').val());
                    discount_value = parseFloat($('#discount_value_header').val().replace(/,/g, ''));
                }
                // convert string date to date
                // var inv_date = new Date(inv_date);
                // var job_date = new Date(job_date);
                // var due_date = new Date(due_date);


                var myJson = {
                    "requestoremail": "benfany.aditia@gmail.com",
                    "customer": customer,
                    "address": address,
                    "quotations": quotations,
                    "notes": notes,
                    "header": header,
                    "footer": footer,
                    "title": title,
                    "status": status,
                    "quot_date": inv_date,
                    // "job_date": job_date,
                    "due_date": due_date,
                    "sub_total": sub_total,
                    "sub_discount_value": sub_discount_value,
                    "discount_type": discount_type,
                    "discount_value": discount_value,
                    "discount": discount,
                    "grand_total": grand_total,
                    "data": []
                };

                var data = [];
                var cardIds = [];
                // get how many id^=card- in #mainContainer save in array 
                $('#mainContainer [id^="card-"]').each(function() {
                    cardIds.push($(this).attr('id'));
                });
                // console.log(cardIds);

                // get data from each card
                for (var i = 0; i < cardIds.length; i++) {
                    var card = $('#' + cardIds[i]);
                    var subData = {
                        "sub_title": card.find('#sub_title').val(),
                        "sub_id": cardIds[i],
                        "details": []
                    };
                    var rowCount = card.find('tbody tr').length;
                    if (rowCount > 0) {
                        // get data from each row in table if #name is not empty
                        card.find('tbody tr').each(function() {

                            var tr = $(this);
                            var item = {};
                            // id_item
                            item.id_item = tr.find('#id_item').val();

                            item.name = tr.find('#name').val();
                            item.type = tr.find('#type').val();
                            item.brand = tr.find('[id^="brand-"]').val();
                            item.price = parseFloat(tr.find('#price').val().replace(
                                /[^0-9\-]+/g,
                                ""));
                            item.qty = parseFloat(tr.find('#qty').val().replace(
                                /[^0-9\-]+/g,
                                ""));
                            item.unit = tr.find('[id^="unit-"]').val();
                            item.item_discount = parseFloat(tr.find('#item_discount').val().replace(
                                /[^0-9\-]+/g,
                                ""));
                            item.ammount = parseFloat(tr.find('#ammount').val().replace(
                                /[^0-9\-]+/g,
                                ""));
                            // get summernote content
                            tr.find('#summernote').summernote('code') != "<p><br></p>" ? item
                                .note = tr.find(
                                    '#summernote').summernote('code') : item.note = "";
                            // if item is not empty
                            if (item.name != '') {

                                subData.details.push(item);
                            }
                        });
                    }
                    data.push(subData);


                }
                myJson.data = data;

                myJson.data = data;
                var data_json = JSON.stringify(myJson);
                console.log(data_json);

                const formData = new FormData(myForm);
                const xhr = new XMLHttpRequest();
                var token = "Bearer " + '{{ session()->get('tokenJwt') }}';
                // console.log(token);

                xhr.open(myForm.method, myForm.action);
                xhr.setRequestHeader("Authorization", "Bearer " +
                    '{{ session()->get('tokenJwt') }}');

                xhr.setRequestHeader("Content-Type", "application/json");
                xhr.send(data_json);
                // on sending show circular progress



                xhr.onload = function() {

                    if (xhr.status === 200) {
                        const response = JSON.parse(xhr.responseText);
                        console.log(response);

                        // sweetalert2 on ok back to list
                        Swal.fire({
                            title: 'Success!',
                            text: response.message,
                            icon: 'success',
                            confirmButtonText: 'OK'
                        }).then(function() {
                            window.location.href = "/list_quotations";
                        });



                    } else {
                        // alert response.message;
                        console.log(xhr.responseText);
                        // sweetalert2
                        Swal.fire({
                            title: 'Error!',
                            text: xhr.responseText,
                            icon: 'error',
                            confirmButtonText: 'Ok'
                        });

                    }
                };




            } else {
                // show alert and tell whivh field is not valid
                Swal.fire({
                    title: 'Error!',
                    text: 'Please fill all required field',
                    icon: 'error',
                    confirmButtonText: 'Ok'
                });




            }
        });
    </script>

    <script>
        $(function() {
            $("#example1").DataTable({
                "responsive": true,
                "lengthChange": true,
                "autoWidth": true,
                "buttons": ["copy", "csv", "excel", "pdf", "print"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": true,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });
        });
    </script>
    {{-- modal script --}}
    <script>
        $(function() {
            $('#exampleModal').on('show.bs.modal', function(event) {
                var button = $(event.relatedTarget) // Button that triggered the modal
                var recipient = button.data('whatever') // Extract info from data-* attributes
                // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
                // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
                var modal = $(this)
                modal.find('.modal-title').text('New message to ' + recipient)
                modal.find('.modal-body input').val(recipient)
            })
        })
    </script>
    <!-- DataTables  & Plugins -->
    <script src=" {{ asset('') }}assets/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/jszip/jszip.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/pdfmake/pdfmake.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/pdfmake/vfs_fonts.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-buttons/js/buttons.print.min.js"></script>
    <script src=" {{ asset('') }}assets/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>


    <script>
        $(function() {
            var Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000
            });

            // // run script when page loaded
            // $(document).ready(function() {

            // });
            // on reload
            @if (session()->has('success'))
                Toast.fire({
                    icon: 'success',
                    title: '{{ session()->get('success') }}',
                    timer: 3000,
                })
            @endif

            @if (session()->has('error'))
                Toast.fire({
                    icon: 'error',
                    title: '{{ session()->get('error') }}',
                    timer: 3000,
                })
            @endif

            $('.swalDefaultSuccess').click(function() {
                Toast.fire({
                    icon: 'success',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.swalDefaultInfo').click(function() {
                Toast.fire({
                    icon: 'info',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.swalDefaultError').click(function() {
                Toast.fire({
                    icon: 'error',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.swalDefaultWarning').click(function() {
                Toast.fire({
                    icon: 'warning',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.swalDefaultQuestion').click(function() {
                Toast.fire({
                    icon: 'question',
                    title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });

            $('.toastrDefaultSuccess').click(function() {
                toastr.success('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
            });
            $('.toastrDefaultInfo').click(function() {
                toastr.info('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
            });
            $('.toastrDefaultError').click(function() {
                toastr.error('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
            });
            $('.toastrDefaultWarning').click(function() {
                toastr.warning('Lorem ipsum dolor sit amet, consetetur sadipscing elitr.')
            });

            $('.toastsDefaultDefault').click(function() {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultTopLeft').click(function() {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    position: 'topLeft',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultBottomRight').click(function() {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    position: 'bottomRight',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultBottomLeft').click(function() {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    position: 'bottomLeft',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultAutohide').click(function() {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    autohide: true,
                    delay: 750,
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultNotFixed').click(function() {
                $(document).Toasts('create', {
                    title: 'Toast Title',
                    fixed: false,
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultFull').click(function() {
                $(document).Toasts('create', {
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    icon: 'fas fa-envelope fa-lg',
                })
            });
            $('.toastsDefaultFullImage').click(function() {
                $(document).Toasts('create', {
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    image: '{{ asset('') }}assets/dist/img/user3-128x128.jpg',
                    imageAlt: 'User Picture',
                })
            });
            $('.toastsDefaultSuccess').click(function() {
                $(document).Toasts('create', {
                    class: 'bg-success',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultInfo').click(function() {
                $(document).Toasts('create', {
                    class: 'bg-info',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultWarning').click(function() {
                $(document).Toasts('create', {
                    class: 'bg-warning',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultDanger').click(function() {
                $(document).Toasts('create', {
                    class: 'bg-danger',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
            $('.toastsDefaultMaroon').click(function() {
                $(document).Toasts('create', {
                    class: 'bg-maroon',
                    title: 'Toast Title',
                    subtitle: 'Subtitle',
                    body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
                })
            });
        });
    </script>
@endpush

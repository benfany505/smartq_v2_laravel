{{-- sub element --}}
@extends('sales.add_invoice')
@section('sub_group')
    <div class="card-body" id="sub_items">
        {{-- button add sub group --}}
        <div class="row">
            <div class="col-sm-12 table-responsive">
                <div class="row">
                    <div class="col-sm-4 mb-2">
                        <input type="text" class="form-control" name="sub_title" id="sub_title" placeholder="Sub Title">
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-12 mb-2">
                        <table class="table text-nowrap table-bordered table-striped table-sm">
                            <thead class="table-primary">
                                <tr class="text-center">

                                    <th width="45%">Name</th>
                                    <th width="10%">Type</th>
                                    <th width="5%">Brand</th>
                                    <th width="10%">Price (IDR)</th>
                                    <th width="5%">Qty</th>
                                    <th width="5%">Unit</th>
                                    <th width="5%">Disc(%)</th>
                                    <th width="10%">Amount (IDR)</th>

                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <input type="text" class="form-control" name="name" id="name"
                                            placeholder="Name">
                                    </td>
                                    <td>
                                        <Select class="select form-control">
                                            <option value="">Select Type</option>
                                            <option value="">Type 1</option>
                                            <option value="">Type 2</option>
                                            <option value="">Type 3</option>
                                        </Select>
                                    </td>
                                    <td>
                                        <Select class="select form-control">
                                            <option value="">Select Brand</option>
                                            <option value="">Brand 1</option>
                                            <option value="">Brand 2</option>
                                            <option value="">Brand 3</option>
                                        </Select>
                                    </td>
                                    <td>
                                        <input type="text" class="form-control" name="price" id="price"
                                            placeholder="Price">
                                    </td>
                                    <td>
                                        <input type="text" class="form-control" name="qty" id="qty"
                                            placeholder="Qty">
                                    </td>
                                    <td>
                                        <Select class="select form-control">
                                            <option value="">Select Unit</option>
                                            <option value="">Unit 1</option>
                                            <option value="">Unit 2</option>
                                            <option value="">Unit 3</option>
                                        </Select>
                                    </td>
                                    <td>
                                        <input type="text" class="form-control" name="disc" id="disc"
                                            placeholder="Disc">
                                    </td>
                                    <td>
                                        <input type="text" class="form-control" name="amount" id="amount"
                                            placeholder="Amount">
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>




                <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i>
                    Add Blank Line</button>
                <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i>
                    Find Item/Service</button>


                <hr>

            </div>
        </div>



    </div>

    {{-- end sub element --}}
@endsection

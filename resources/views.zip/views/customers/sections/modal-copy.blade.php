<section class="modal-copy">
    <div class="modal fade " style="overflow:hidden;" role="dialog" id="modal-copy-{{ $customer['id_customer'] }}">
        <div class="modal-dialog  modal-xl">
            <div class="modal-content">
                <div class="card card-success mb-0">
                    <h4 class="card-header">Copy Customer {{ $customer['id_customer'] }}</h4>
                    <form class="form-horizontal" action="/add_customer" method="POST">
                        @csrf
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-6 pl-5 pr-5">
                                    <div class="form-group row">
                                        <label for="name-copy-{{ $customer['id_customer'] }}"
                                            class="col-sm-3 col-form-label  ">Name</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control"
                                                id="name-copy-{{ $customer['id_customer'] }}" placeholder="Name"
                                                name="name" value="{{ $customer['name'] }}">
                                        </div>
                                    </div>
                                    {{-- dropdown box --}}
                                    <div class="form-group row">
                                        <label for="company-copy-{{ $customer['id_customer'] }}"
                                            class="col-sm-3 col-form-label  ">Company</label>
                                        <div class="col-sm-9">
                                            <div class="input-group">
                                                <div style="width: 85%">
                                                    <select class="form-control select-inmodal" name="company"
                                                        id="company-copy-{{ $customer['id_customer'] }}">
                                                        <option value=""></option>
                                                        @foreach ($companies as $company)
                                                            <option value="{{ $company['name'] }}">
                                                                {{ $company['name'] }}
                                                            </option>
                                                        @endforeach

                                                    </select>
                                                </div>

                                                <div class="text-right" style="width: 15%">
                                                    <a href="/list_companies" class="btn btn-success"><i
                                                            class="fa fa-plus"></i></a>
                                                </div>


                                            </div>
                                        </div>

                                    </div>
                                    <div class="form-group row">
                                        <label for="email-copy-{{ $customer['id_customer'] }}"
                                            class="col-sm-3 col-form-label  ">Email</label>
                                        <div class="col-sm-9">
                                            <input type="email" class="form-control"
                                                id="email-copy-{{ $customer['id_customer'] }}" placeholder="Email"
                                                name="email">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="phone-copy-{{ $customer['id_customer'] }}"
                                            class="col-sm-3 col-form-label  ">Phone</label>
                                        <div class="col-sm-9">
                                            <input type="phone" class="form-control"
                                                id="phone-copy-{{ $customer['id_customer'] }}" placeholder="Phone"
                                                name="phone">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="address-copy-{{ $customer['id_customer'] }}"
                                            class="col-sm-3 col-form-label  ">Address</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control"
                                                id="address-copy-{{ $customer['id_customer'] }}"
                                                placeholder="Address" name="address">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="city-copy-{{ $customer['id_customer'] }}"
                                            class="col-sm-3 col-form-label  ">City</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control"
                                                id="city-copy-{{ $customer['id_customer'] }}" placeholder="City"
                                                name="city">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="state-copy-{{ $customer['id_customer'] }}"
                                            class="col-sm-3 col-form-label  ">State</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control"
                                                id="state-copy-{{ $customer['id_customer'] }}" placeholder="State"
                                                name="state">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="zip_code-copy-{{ $customer['id_customer'] }}"
                                            class="col-sm-3 col-form-label  ">Zip Code</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control"
                                                id="zip_code-copy-{{ $customer['id_customer'] }}"
                                                placeholder="Zip/Postal Code" name="zip_code">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="country-copy-{{ $customer['id_customer'] }}"
                                            class="col-sm-3 col-form-label  ">Country</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control"
                                                id="country-copy-{{ $customer['id_customer'] }}"
                                                placeholder="Country" name="country">
                                        </div>
                                    </div>


                                </div>

                                <div class="col-lg-6 pl-5 pr-5">
                                    <div class="form-group row">
                                        <label for="currency-copy-{{ $customer['id_customer'] }}"
                                            class="col-sm-3 col-form-label  ">Currency</label>
                                        <div class="col-sm-9">
                                            <select class="form-control" name="currency"
                                                id="currency-copy-{{ $customer['id_customer'] }}">
                                                <option>Select Currency</option>
                                                <option>IDR</option>
                                                <option>USD</option>
                                            </select>
                                        </div>
                                    </div>
                                    {{-- password --}}
                                    <div class="form-group row">
                                        <label for="password-copy-{{ $customer['id_customer'] }}"
                                            class="col-sm-3 col-form-label  ">Password</label>
                                        <div class="col-sm-9">
                                            <input type="password" class="form-control"
                                                id="password-copy-{{ $customer['id_customer'] }}"
                                                placeholder="Password" name="password">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="confirm_password-copy-{{ $customer['id_customer'] }}"
                                            class="col-sm-3 col-form-label  ">Re-Type</label>
                                        <div class="col-sm-9">
                                            <input type="password" class="form-control"
                                                id="confirm_password-copy-{{ $customer['id_customer'] }}"
                                                placeholder="Confirm Password" name="confirm_password">
                                        </div>
                                    </div>

                                    {{-- enable login switch --}}
                                    <div class="form-group row">
                                        <label for="enabled-copy-{{ $customer['id_customer'] }}"
                                            class="col-sm-3 col-form-label  "></label>
                                        <div class="col-sm-9">
                                            <div class="custom-control custom-checkbox ">
                                                <input class="custom-control-input" type="checkbox"
                                                    id="enabled-copy-{{ $customer['id_customer'] }}" name="enabled"
                                                    checked>
                                                <label for="enabled-copy-{{ $customer['id_customer'] }}"
                                                    class="custom-control-label">Enable
                                                    Login</label>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>


                        </div>

                        <div class="card-footer">
                            <button type="submit" class="btn btn-success">Save</button>
                            {{-- button dismiss modal --}}
                            <button type="button" class="btn btn-default float-right"
                                data-dismiss="modal">Cancel</button>
                            {{-- cancel button back to home --}}
                            {{-- <a href="/list_customers" class="btn btn-default float-right">Cancel</a> --}}

                        </div>
                    </form>

                </div>

            </div>

        </div>
        <!-- /.modal-dialog -->
    </div>
</section>

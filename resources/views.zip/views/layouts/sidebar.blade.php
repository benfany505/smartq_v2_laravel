  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
      <!-- Brand Logo -->
      <a href="./" class="brand-link">
          <img src="{{ asset('') }}assets/dist/img/logo_etn.png" alt="ETN Logo"
              class="brand-image img-circle elevation-1" style="opacity: 2">
          <span class="brand-text font-weight-light text-sm">EZA TEKNOLOGI NUSANTARA</span>
      </a>

      <!-- Sidebar -->
      <div class="sidebar">
          <!-- Sidebar user panel (optional) -->
          <div class="user-panel mt-3 pb-3 mb-3 d-flex">
              <div class="image">
                  <img src="{{ asset('') }}assets/dist/img/rayyan.jpg" class="img-circle elevation-2"
                      alt="User Image">
              </div>
              {{-- <div class="info">
                  <a href="#" class="d-block">Benfany Aditia</a>
              </div> --}}
              @if (Auth::check())
                  <div class="info">
                      <a href="#" class="d-block">{{ Auth::user()->name }}</a>
                  </div>
              @endif
          </div>

          <!-- SidebarSearch Form -->
          <div class="form-inline">
              <div class="input-group" data-widget="sidebar-search">
                  <input class="form-control form-control-sidebar" type="search" placeholder="Search"
                      aria-label="Search">
                  <div class="input-group-append">
                      <button class="btn btn-sidebar">
                          <i class="fas fa-search fa-fw"></i>
                      </button>
                  </div>
              </div>
          </div>

          <!-- Sidebar Menu -->
          <nav class="mt-3 " style="padding-bottom: 70px">
              <ul class="nav nav-pills nav-sidebar flex-column nav-legacy text-sm" data-widget="treeview" role="menu"
                  data-accordion="false">
                  {{-- <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                  data-accordion="false"> --}}
                  <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
                  {{-- <li class="nav-item">
                      <a href="./" class="nav-link">
                          <i class="nav-icon fas fa-th"></i>
                          <p>
                              Dashboard

                          </p>
                      </a>
                  </li> --}}
                  <li class="nav-item">
                      <a href="/dashboard" class="nav-link">
                          <i class="nav-icon fas fa-home"></i>
                          <p>
                              Dashboard

                          </p>
                      </a>
                  </li>
                  <li class="nav-item">
                      <a href="/list_customers" class="nav-link">
                          <i class="nav-icon fas fa-people-arrows"></i>
                          <p>
                              Customers
                          </p>
                      </a>
                  </li>
                  {{-- Customers --}}
                  {{-- <li class="nav-item menu-close">
                      <a href="#" class="nav-link">
                          <i class="nav-icon fas fa-people-arrows"></i>
                          <p>
                              Customers
                              <i class="right fas fa-angle-left"></i>
                          </p>
                      </a>
                      <ul class="nav nav-treeview">
                          <li class="nav-item">
                              <a href="./add_customer" class="nav-link ">
                                  <i class="far  nav-icon"></i>
                                  <p>Add Customer</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="./list_customers" class="nav-link">
                                  <i class="far  nav-icon"></i>
                                  <p>List Customers</p>
                              </a>
                          </li>

                      </ul>
                  </li> --}}
                  <li class="nav-item">
                      <a href="/list_companies" class="nav-link">
                          <i class="nav-icon fas fa-building"></i>
                          <p>
                              Companies
                          </p>
                      </a>
                  </li>
                  {{-- Companies --}}

                  {{-- <li class="nav-item menu-close">
                      <a href="#" class="nav-link">
                          <i class="nav-icon fas fa-building"></i>
                          <p>
                              Companies
                              <i class="right fas fa-angle-left"></i>
                          </p>
                      </a>
                      <ul class="nav nav-treeview">
                          {{-- <li class="nav-item">
                              <a href="./add_company" class="nav-link ">
                                  <i class="far  nav-icon"></i>
                                  <p>Add Company</p>
                              </a>
                          </li> 
                  <li class="nav-item">
                      <a href="./list_companies" class="nav-link">
                          <i class="far  nav-icon"></i>
                          <p>List Companies</p>
                      </a>
                  </li>

              </ul>
              </li> --}}
                  {{-- sales --}}
                  <li class="nav-item menu-close">
                      <a href="#" class="nav-link ">
                          <i class="nav-icon fas fa-book"></i>
                          <p>
                              Sales
                              <i class="right fas fa-angle-left"></i>
                          </p>
                      </a>
                      <ul class="nav nav-treeview">
                          <li class="nav-item">
                              <a href="/list_invoices" class="nav-link ">
                                  <i class="far  nav-icon"></i>
                                  <p>Invoices</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/list_quotations" class="nav-link">
                                  <i class="far  nav-icon"></i>
                                  <p>Quotations</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/list_payments" class="nav-link">
                                  <i class="far  nav-icon"></i>
                                  <p>Payments</p>
                              </a>
                          </li>

                      </ul>
                  </li>
                  {{-- Products and Services --}}
                  <li class="nav-item menu-close">
                      <a href="#" class="nav-link ">
                          <i class="nav-icon fas fa-gift"></i>
                          <p>
                              Products & Services
                              <i class="right fas fa-angle-left"></i>
                          </p>
                      </a>
                      <ul class="nav nav-treeview">

                          <li class="nav-item">
                              <a href="/list_products" class="nav-link">
                                  <i class="far  nav-icon"></i>
                                  <p>Products</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/list_services" class="nav-link">
                                  <i class="far  nav-icon"></i>
                                  <p>Services</p>
                              </a>
                          </li>

                      </ul>
                  </li>
                  {{-- Data Support --}}
                  <li class="nav-item menu-close">
                      <a href="#" class="nav-link ">
                          <i class="nav-icon far fa-file-code"></i>
                          <p>
                              Data Support
                              <i class="right fas fa-angle-left"></i>
                          </p>
                      </a>
                      <ul class="nav nav-treeview">

                          <li class="nav-item">
                              <a href="/list_brands" class="nav-link">
                                  <i class="far  nav-icon"></i>
                                  <p>Brands</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/list_units" class="nav-link">
                                  <i class="far  nav-icon"></i>
                                  <p>Units</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/list_categories" class="nav-link">
                                  <i class="far  nav-icon"></i>
                                  <p>Categories</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/list_income_cat" class="nav-link">
                                  <i class="far  nav-icon"></i>
                                  <p>Income</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/list_expense_cat" class="nav-link">
                                  <i class="far  nav-icon"></i>
                                  <p>Expense</p>
                              </a>
                          </li>

                      </ul>
                  </li>
                  {{-- Bank and Cash --}}
                  <li class="nav-item menu-close">
                      <a href="#" class="nav-link ">
                          <i class="nav-icon fas fa-university"></i>
                          <p>
                              Bank & Cash
                              <i class="right fas fa-angle-left"></i>
                          </p>
                      </a>
                      <ul class="nav nav-treeview">

                          <li class="nav-item">
                              <a href="/list_accounts" class="nav-link">
                                  <i class="far  nav-icon"></i>
                                  <p>List Accounts</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/account_balances" class="nav-link">
                                  <i class="far  nav-icon"></i>
                                  <p>Accounts Balances</p>
                              </a>
                          </li>

                      </ul>
                  </li>
                  {{-- Transcation --}}
                  {{-- <li class="nav-item menu-close">
                      <a href="#" class="nav-link ">
                          <i class="nav-icon fa fa-exchange-alt"></i>
                          <p>
                              Transactions
                              <i class="right fas fa-angle-left"></i>
                          </p>
                      </a>
                      <ul class="nav nav-treeview">

                          <li class="nav-item">
                              <a href="/list_incomes" class="nav-link">
                                  <i class="far  nav-icon"></i>
                                  <p>Incomes</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/list_expenses" class="nav-link">
                                  <i class="far  nav-icon"></i>
                                  <p>Expenses</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/add_transfer" class="nav-link">
                                  <i class="far  nav-icon"></i>
                                  <p>Transfer</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/list_transactions" class="nav-link">
                                  <i class="far  nav-icon"></i>
                                  <p>Transactions</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/list_balance" class="nav-link">
                                  <i class="far  nav-icon"></i>
                                  <p>Balance Sheet</p>
                              </a>
                          </li>

                      </ul>
                  </li> --}}
                  {{-- Reports --}}
                  {{-- <li class="nav-item menu-close">
                      <a href="#" class="nav-link ">
                          <i class="nav-icon fas fa-chart-bar"></i>
                          <p>
                              Reports
                              <i class="right fas fa-angle-left"></i>
                          </p>
                      </a>
                      <ul class="nav nav-treeview">

                          <li class="nav-item">
                              <a href="/index2.html" class="nav-link">
                                  <i class="far  nav-icon"></i>
                                  <p>Income Reports</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/index2.html" class="nav-link">
                                  <i class="far nav-icon"></i>
                                  <p>Expense Reports</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/index2.html" class="nav-link">
                                  <i class="far nav-icon"></i>
                                  <p>Income vs Expense</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/index2.html" class="nav-link">
                                  <i class="far nav-icon"></i>
                                  <p>Reports by Date</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/index2.html" class="nav-link">
                                  <i class="far nav-icon"></i>
                                  <p>All Income</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/index2.html" class="nav-link">
                                  <i class="far nav-icon"></i>
                                  <p>All Expense</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/index2.html" class="nav-link">
                                  <i class="far nav-icon"></i>
                                  <p>All Transactions</p>
                              </a>
                          </li>

                      </ul>
                  </li> --}}
                  {{-- <li class="nav-item menu-close">
                      <a href="#" class="nav-link ">
                          <i class="nav-icon fas fa-cog"></i>
                          <p>
                              Settings
                              <i class="right fas fa-angle-left"></i>
                          </p>
                      </a>
                      <ul class="nav nav-treeview">

                          <li class="nav-item">
                              <a href="/index2.html" class="nav-link">
                                  <i class="far  nav-icon"></i>
                                  <p>General Settings</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/index2.html" class="nav-link">
                                  <i class="far nav-icon"></i>
                                  <p>Staff</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/index2.html" class="nav-link">
                                  <i class="far nav-icon"></i>
                                  <p>Roles</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/index2.html" class="nav-link">
                                  <i class="far nav-icon"></i>
                                  <p>Localization</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="./index2.html" class="nav-link">
                                  <i class="far nav-icon"></i>
                                  <p>Currencies</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/index2.html" class="nav-link">
                                  <i class="far nav-icon"></i>
                                  <p>Email Templates</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/index2.html" class="nav-link">
                                  <i class="far nav-icon"></i>
                                  <p>About</p>
                              </a>
                          </li>

                      </ul>
                  </li> --}}
                  {{-- devider line horizontal --}}
                  {{-- <li class="nav-item" style=" border-top: 1px solid rgb(63, 71, 78);"></li> --}}

                  <li class="nav-item menu-close">
                      <a href="#" class="nav-link ">
                          <i class="nav-icon fas fa-user"></i>
                          <p>
                              My Profile
                              <i class="right fas fa-angle-left"></i>
                          </p>
                      </a>
                      <ul class="nav nav-treeview">

                          <li class="nav-item">
                              <a href="./index2.html" class="nav-link">
                                  <i class="far  nav-icon"></i>
                                  <p>Edit Profile</p>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a href="/logout" class="nav-link"
                                  onclick="event.preventDefault(); document.getElementById('formLogout').submit()">
                                  <i class="far  nav-icon"></i>
                                  <p>Logout</p>

                              </a>
                              <form method="POST" id="formLogout" action="/logout">@csrf</form>
                          </li>

                      </ul>
                  </li>


              </ul>
          </nav>
          <!-- /.sidebar-menu -->
      </div>
      <!-- /.sidebar -->
  </aside>

@extends('layouts.master')
@section('title', 'ETN | Invoice')
@push('custom-css')
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet"
        href="{{ asset('') }}assets/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="{{ asset('') }}assets/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- JQVMap -->
    <link rel="stylesheet" href="{{ asset('') }}assets/plugins/jqvmap/jqvmap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="{{ asset('') }}assets/dist/css/adminlte.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="{{ asset('') }}assets/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="{{ asset('') }}assets/plugins/daterangepicker/daterangepicker.css">
    <!-- summernote -->
    <link rel="stylesheet" href="{{ asset('') }}assets/plugins/summernote/summernote-bs4.min.css">
@endpush
@section('content')
    {{-- toast if success --}}
    {{-- check success message --}}



    <div class="container-fluid">

        <div class="row">
            <div class="col-lg-12">
                <div class="card card-info">
                    <div class="card-header">
                        <h3 class="card-title">Add Product</h3>
                    </div>
                    <form class="form-horizontal" action="/add_product" method="POST">
                        @csrf
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-6 pl-5 pr-5">
                                    <div class="form-group row">
                                        <label for="inputEmail3" class="col-sm-3 col-form-label  ">Name</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="name" name="name"
                                                placeholder="Name">
                                        </div>
                                    </div>
                                    {{-- dropdown box --}}

                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label">Description</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="desc" name="desc"
                                                placeholder="Description">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label  ">Type</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="type" name="type"
                                                placeholder="Type / Specs">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label  ">Brand</label>
                                        <div class="col-sm-9">
                                            {{-- drop down menu and plus icon --}}
                                            <div class="input-group">
                                                <select class=" select form-control " id="brand" name="brand" required>
                                                    <option value=""></option>
                                                    {{-- <option selected hidden>Select Brand</option> --}}
                                                    @foreach ($brands as $brand)
                                                        <option value="{{ $brand['id'] }}">{{ $brand['name'] }}</option>
                                                    @endforeach
                                                </select>
                                                <div class="input-group-append">
                                                    <button class="btn btn-primary" type="button">
                                                        <i class="fas fa-plus"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label  ">Price(IDR)</label>
                                        <div class="col-sm-9">
                                            <input type="number" class="form-control" id="price" name="price"
                                                placeholder="Price">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label  ">Unit</label>
                                        <div class="col-sm-9">
                                            {{-- drop down menu and plus icon --}}
                                            <div class="input-group">
                                                <select class=" select form-control " id="unit" name="unit" required>
                                                    <option value=""></option>
                                                    <option>pcs</option>
                                                    <option>mtr</option>
                                                    <option>roll</option>
                                                </select>
                                                <div class="input-group-append">
                                                    <button class="btn btn-primary" type="button">
                                                        <i class="fas fa-plus"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label  ">Category</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="category" name="category"
                                                placeholder="Category">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card-footer">
                            <button type="submit" class="btn btn-info">Save</button>
                            {{-- cancel button back to home --}}
                            <a href="/list_products" class="btn btn-default float-right">Cancel</a>

                        </div>
                    </form>


                </div>

            </div>

        </div>
    @endsection
    @push('custom-js')
        <!-- jQuery UI 1.11.4 -->
        <script src="{{ asset('') }}assets/plugins/jquery-ui/jquery-ui.min.js"></script>
        <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
        <script>
            $.widget.bridge('uibutton', $.ui.button)
        </script>
        <!-- Bootstrap 4 -->
        <script src="{{ asset('') }}assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
        <!-- ChartJS -->
        <script src="{{ asset('') }}assets/plugins/chart.js/Chart.min.js"></script>
        <!-- Sparkline -->
        <script src="{{ asset('') }}assets/plugins/sparklines/sparkline.js"></script>
        <!-- JQVMap -->
        <script src="{{ asset('') }}assets/plugins/jqvmap/jquery.vmap.min.js"></script>
        <script src="{{ asset('') }}assets/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
        <!-- jQuery Knob Chart -->
        <script src="{{ asset('') }}assets/plugins/jquery-knob/jquery.knob.min.js"></script>
        <!-- daterangepicker -->
        <script src="{{ asset('') }}assets/plugins/moment/moment.min.js"></script>
        <script src="{{ asset('') }}assets/plugins/daterangepicker/daterangepicker.js"></script>
        <!-- Tempusdominus Bootstrap 4 -->
        <script src="{{ asset('') }}assets/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
        <!-- Summernote -->
        <script src="{{ asset('') }}assets/plugins/summernote/summernote-bs4.min.js"></script>
        <!-- overlayScrollbars -->
        <script src="{{ asset('') }}assets/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
    @endpush
